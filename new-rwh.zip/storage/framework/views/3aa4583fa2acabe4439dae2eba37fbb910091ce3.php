<?php
    use App\SubModul;
    use App\JenisMapping;
?>
<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="<?php echo e(route('deleteMapping')); ?>" method="post">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">Current Mapping</h4>

                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Modul</th>
                            <th>Nama Submodul</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $currents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" id="current[]" name="current[]" value="<?php echo e($current->id); ?>">
                                        <label class="form-check-label" for="autoSizingCheck">
                                            <?php echo e($i); ?>

                                        </label>
                                    </div>
                                </td>
                                <td><?php echo e(SubModul::where('submodul_id',$current->submodul_id)->first()->modul()->first()->modul_desc); ?></td>
                                <td><?php echo e($current->submodul->submodul_desc); ?></td>
                                <?php ($jenismapping = JenisMapping::where('mapping_id',$current->id)->get()); ?>
                                <td>
                                    
                                </td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>

    
    <form action="<?php echo e(route('storeMapping')); ?>" method="post">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">List Modul</h4>

                    <table id="responsive-datatable2" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Modul</th>
                            <th>Nama Submodul</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $rests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="checkbox" id="rest[]" name="rest[]" value="<?php echo e($rest->submodul_id); ?>">
                                        <label class="form-check-label" for="autoSizingCheck">
                                            <?php echo e($i); ?>

                                        </label>
                                    </div>
                                </td>
                                <td><?php echo e(SubModul::where('submodul_id',$rest->submodul_id)->first()->modul()->first()->modul_desc); ?></td>
                                <td><?php echo e($rest->submodul_desc); ?></td>
                                <td>
                                    
                                </td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<script type="text/javascript">

    $(document).ready(function () {

        // Responsive Datatable
        $('.table').DataTable();
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\rwh\resources\views/menumapping/form.blade.php */ ?>