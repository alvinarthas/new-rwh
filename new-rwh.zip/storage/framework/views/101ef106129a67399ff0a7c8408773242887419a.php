<?php if($jenis == "print"): ?>
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />
<?php endif; ?>
<div class="row" id="print-area">
    <div class="col-md-12">
        <div class="card-box">
            <!-- <div class="panel-heading">
                <h4>Invoice</h4>
            </div> -->
            <div class="panel-body">
                <div class="clearfix">
                    <div class="pull-left">
                        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
                    </div>
                    <div class="pull-right">
                        <h4>Sales Order Invoice # <br>
                        </h4>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">

                        <div class="pull-left m-t-30">
                            <address>
                                <strong>ROYAL WAREHOUSE HERBAL STORE</strong><br>
                                <?php echo e($transaksi->customer->apadd); ?><br>
                                Telepon: <?php echo e($transaksi->customer->apphone); ?>

                            </address>
                        </div>
                        <div class="pull-right m-t-30">
                            <p><strong>Customer Name: </strong> <?php echo e($transaksi->customer->apname); ?></p>
                            <p><strong>Transaction Date: </strong> <?php echo e($transaksi->trx_date); ?></p>
                            <p class="m-t-10"><strong>Transaction ID: </strong> #<?php echo e($transaksi->id); ?></p>
                        </div>
                    </div><!-- end col -->
                </div>
                <!-- end row -->

                <div class="m-h-50"></div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table m-t-30">
                                <thead>
                                <tr><th>#</th>
                                    <th>Item</th>
                                    <th>Qty</th>
                                    <th>Unit</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr></thead>
                                <tbody>
                                  <?php ($i=1); ?>
                                  <?php $__currentLoopData = $transaksidet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td><?php echo e($i); ?></td>
                                      <td><?php echo e($item->product->name); ?></td>
                                      <td><?php echo e($item->qty); ?></td>
                                      <td><?php echo e($item->unit); ?></td>
                                      <td>Rp. <?php echo e(number_format($item->price)); ?></td>
                                      <td>Rp. <?php echo e(number_format($item->sub_ttl)); ?></td>
                                    </tr>
                                  <?php ($i++); ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <hr>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-6 col-6">
                        <div class="clearfix m-t-40">
                            <div class="col-6">
                                <h5 class="small text-inverse font-600">Nama Pengirim:</h5>
                                <h5 class="small text-inverse font-600">Tanda Tangan:</h5><br><br>
                            </div>
                            <div class="col-6">
                                <h5 class="small text-inverse font-600">Nama Penerima:</h5>
                                <h5 class="small text-inverse font-600">Tanda Tangan:</h5><br><br>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-6 offset-xl-3">
                        <p class="text-right"><b>Sub-total:</b> Rp. <?php echo e(number_format($transaksi->ttl_harga)); ?></p>
                        <p class="text-right">Ongkir: Rp. <?php echo e(number_format($transaksi->ongkir)); ?></p>
                        <hr>
                        <h3 class="text-right">Rp. <?php echo e(number_format($transaksi->ongkir+$transaksi->ttl_harga)); ?></h3>
                    </div>
                </div>
                <hr>
                <div class="d-print-none">
                    <div class="pull-right">
                        <a href="#" class="btn btn-danger btn-rounded waves-effect w-md waves-danger m-b-5" onclick="printPdf()"><i class="fa fa-print"></i>Print PDF</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

    </div>

</div>

<script>
  function printPdf(){
    url = "<?php echo e(route('invoicePrint',['jenis' => 'Print','trx_id'=>22])); ?>";
    windowUrl = url.replace("&amp", "");
    windowName = "Invoice";
    var printWindow = window.open(windowUrl, windowName, 'left=50000,top=50000,width=0,height=0');
    printWindow.focus();
    printWindow.print();
  }
    
</script><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/sales/invoice/pdf.blade.php ENDPATH**/ ?>