<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    
    <link href="<?php echo e(asset('assets/fingerprint/ajaxmask.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
    Kehadiran
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card-box">
            <h4 class="m-t-0 header-title">Kehadiran</h4>
            <p class="text-muted m-b-30 font-14">
            </p>
            <div class="form-group text-left m-b-0">
                <?php if(array_search("ABKER",$page)): ?>
                    <a href="<?php echo e(route('absensiRegister')); ?>" class="btn btn-primary btn-rounded waves-effect waves-light w-md m-b-5">Registrasi</a>
                <?php endif; ?>
                <?php if(array_search("ABLOV",$page2)): ?>
                    <a href="<?php echo e(route('absensiLog')); ?>" class="btn btn-danger btn-rounded waves-effect waves-light w-md m-b-5">Full Log</a>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="p-20">
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Daftar Anggota</label>
                            <div class="col-10">
                                <select class="form-control select2" parsley-trigger="change" name="anggota" id="anggota" onchange="chooseUser(this.value)">
                                    <option value="#" disabled selected>Pilih Anggota</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->user_id); ?>" data-image="<?php echo e(asset('assets/images/employee/foto/'.$user->user->scanfoto)); ?>"><?php echo e($user->user_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-2 col-form-label">Keterangan</label>
                            <div class="col-10">
                                <select class="form-control select2" parsley-trigger="change" name="keterangan" id="keterangan" onchange="chooseKeterangan(this.value)">
                                    <option value="masuk">Masuk Kerja</option>
                                    <option value="pulang">Pulang Kerja</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="btnAbsen" style="display:none">
            </div>
        </div>
    </div>
</div>

<div class="row" id="logTabel">

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/fingerprint/ajaxmask.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script>
        // Select2
        $(".select2").select2({
            templateResult: formatState,
            templateSelection: formatState
        });

        function formatState (opt) {
            if (!opt.id) {
                return opt.text.toUpperCase();
            }

            var optimage = $(opt.element).attr('data-image');
            console.log(optimage)
            if(!optimage){
                return opt.text.toUpperCase();
            } else {
                var $opt = $(
                '<span><img src="' + optimage + '" width="30px" /> ' + opt.text.toUpperCase() + '</span>'
                );
                return $opt;
            }
        }

        function chooseUser(id){
            var keterangan = $("#keterangan").val();
            var base = "<?php echo route('fingerVerifikasi'); ?>";
            var url = btoa(base+'?user_id='+id+'&keterangan='+keterangan+'');
            var button = '<a href="finspot:FingerspotVer;'+url+'" class="btn btn-purple btn-rounded waves-effect waves-light w-md m-b-5" onclick="verifikasiLog('+id+')">VERIFIKASI</a>';
            $('#btnAbsen').html(button).show();
            showLog(id);
        }

        function chooseKeterangan(keterangan){
            var id = $("#anggota").val();
            var base = "<?php echo route('fingerVerifikasi'); ?>";
            var url = btoa(base+'?user_id='+id+'&keterangan='+keterangan+'');
            var button = '<a href="finspot:FingerspotVer;'+url+'" class="btn btn-purple btn-rounded waves-effect waves-light w-md m-b-5" onclick="verifikasiLog('+id+')">VERIFIKASI</a>';
            $('#btnAbsen').html(button).show();
            showLog(id);
        }

        function showLog(id){
            $.ajax({
                url         :   "<?php echo e(route('fingerAjxLog')); ?>",
                data        :   {
                    user_id : id,
                },
                type		:	"GET",
                dataType    :   "html",
                success		:	function(data){
                    $("#logTabel").html(data);
                    // $('#responsive-datatable').DataTable();
                },
            });
        }

        function verifikasiLog(id){
            setTimeout(function(){
                $.ajax({
                    url         :   "<?php echo e(route('fingerAjxLog')); ?>",
                    data        :   {
                        user_id : id,
                    },
                    type		:	"GET",
                    dataType    :   "html",
                    success		:	function(data){
                        $("#logTabel").html(data);
                        // $('#responsive-datatable').DataTable();
                    }
                });
            }, 10000);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/absensi/kehadiran.blade.php ENDPATH**/ ?>