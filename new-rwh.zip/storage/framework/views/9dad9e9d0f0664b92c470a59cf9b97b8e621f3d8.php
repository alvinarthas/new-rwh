<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Balance Sheet (Neraca Saldo Awal)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">Balance Sheet(Neraca Saldo Awal)</h4>
                    
                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th colspan="2" style="text-align:center;background:dodgerblue">Aktiva</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dataaktvia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="font-weight: bold">
                                    <td><?php echo e($item['grup']['AccNo']); ?> - <?php echo e($item['grup']['AccName']); ?></td>
                                    <td style="text-align:right">Rp. <?php echo e(number_format($item['sum'])); ?></td>
                                </tr>

                                <?php $__currentLoopData = $item['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>&ensp;&ensp;<?php echo e($item2['AccNo']); ?> - <?php echo e($item2['AccName']); ?></td>
                                        <td style="text-align:right">Rp. <?php echo e(number_format($item2['SaldoAwal'])); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <td colspan="2" style="text-align:center;font-weight: bold">Total Aktiva: Rp. <?php echo e(number_format($sum_aktiva)); ?></td>
                        </tfoot>
                    </table>
                    <br><br><br>
                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th colspan="2" style="text-align:center;background:lightseagreen">Pasiva</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $datapasiva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="font-weight: bold">
                                    <td><?php echo e($item3['grup']['AccNo']); ?> - <?php echo e($item3['grup']['AccName']); ?></td>
                                    <td style="text-align:right">Rp. <?php echo e(number_format($item3['sum'])); ?></td>
                                </tr>

                                <?php $__currentLoopData = $item3['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>&ensp;&ensp;<?php echo e($item4['AccNo']); ?> - <?php echo e($item4['AccName']); ?></td>
                                        <td style="text-align:right">Rp. <?php echo e(number_format($item4['SaldoAwal'])); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <td colspan="2" style="text-align:center;font-weight: bold">Total Pasiva: Rp. <?php echo e(number_format($sum_pasiva)); ?></td>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/laporan/balance_sheet/neraca_saldo_awal.blade.php ENDPATH**/ ?>