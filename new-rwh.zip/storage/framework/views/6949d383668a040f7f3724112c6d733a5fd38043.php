<?php
    use Carbon\Carbon;
?>
<div class="card-box table-responsive">
    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <th>Jurnal ID</th>
            <th>Transaction Date</th>
            <th>Account Number</th>
            <th>Account Name</th>
            <th>Position</th>
            <th>Amount</th>
            <th>Notes</th>
            <th>Description</th>
        </thead>
        <tbody>
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $jurnals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($jurnal->id_jurnal); ?></td>
                    <td><?php echo e(Carbon::parse($jurnal->date)->format('d M Y')); ?></td>
                    <td><?php echo e($jurnal->AccNo); ?></td>
                    <td><?php echo e($jurnal->coa->AccName); ?></td>
                    <td><?php echo e($jurnal->AccPos); ?></td>
                    <td><?php echo e(number_format($jurnal->Amount)); ?></td>
                    <td><?php echo e($jurnal->description); ?></td>
                    <td><?php echo e($jurnal->notes_item); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/laporan/general_ledger/viewjurnal.blade.php ENDPATH**/ ?>