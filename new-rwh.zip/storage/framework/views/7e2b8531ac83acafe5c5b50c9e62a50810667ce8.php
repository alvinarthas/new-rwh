<?php
    use App\Employee;
    use App\DemoFinger;
?>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!--venobox lightbox-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/magnific-popup/dist/magnific-popup.css')); ?>"/>
    
    
    <link href="<?php echo e(asset('assets/fingerprint/ajaxmask.css')); ?>" rel="stylesheet">
    <!-- Sweet Alert css -->
    <link href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <style>
    img.photo{
        display:block; width:50%; height:auto;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Index Employee</h4>
                <p class="text-muted font-14 m-b-30">
                    <?php if(array_search("EMEMC",$page)): ?>
                        <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Pegawai</a>
                    <?php endif; ?>
                </p>

                <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>NIP</th>
                        <th>Mulai Kerja</th>
                        <th>Alamat</th>
                        <th>No Hp</th>
                        <th>Action</th>
                        <th>Tempat Lahir</th>
                        <th>Tanggal Lahir</th>
                        <th>KTP</th>
                        <th>SIM A</th>
                        <th>SIM B</th>
                        <th>SIM C</th>
                        <th>NPWP</th>
                        <th>BPJS</th>
                    </thead>

                    <tbody>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/foto/'.$emp->scanfoto)); ?>" class="image-popup" title="<?php echo e($emp->name); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/foto/'.$emp->scanfoto)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td><?php echo e($emp->name); ?></td>
                            <td><?php echo e($emp->username); ?></td>
                            <td><?php echo e($emp->nip); ?></td>
                            <td><?php echo e($emp->mulai_kerja); ?></td>
                            <td><?php echo e($emp->address); ?></td>
                            <td><?php echo e($emp->phone); ?></td>
                            <?php
                                $url_register		= base64_encode(route('fingerRegister',['user_id'=>$emp->id]));
                                $finger = DemoFinger::where('user_id',$emp->id)->count();
                            ?>
                            <code style="display: none;" id="user_finger_<?php echo e($emp->id); ?>"><?php echo e($finger); ?></code>
                            <td>
                                <?php if(array_search("EMEMU",$page)): ?>
                                    <a href="<?php echo e(route('employee.edit',['id'=>$emp->id])); ?>" class="btn btn-custom btn-rounded waves-effect waves-light w-md m-b-5">Edit</a>
                                <?php endif; ?>
                                <?php if(array_search("EMEMD",$page)): ?>
                                    <a href="javascrip:;" class="btn btn-danger btn-rounded waves-effect waves-light w-md m-b-5" onclick="deleteEmployee(<?php echo e($emp->id); ?>)">Hapus</a>
                                <?php endif; ?>
                                <div id="fingerprint<?php echo e($emp->id); ?>">
                                <?php if($finger == 0): ?>
                                    <a href="finspot:FingerspotReg;<?=$url_register?>" class="btn btn-purple btn-rounded waves-effect waves-light w-md m-b-5" onclick="user_register(<?php echo e($emp->id); ?>,'<?php echo e($emp->username); ?>')">Daftar Fingerprint</a>
                                <?php else: ?>
                                    <a class="btn btn-purple btn-rounded waves-effect waves-light w-md m-b-5">Fingerprint sudah terdaftar</a>
                                <?php endif; ?>
                                </div>
                            </td>
                            <td><?php echo e($emp->tmpt_lhr); ?></td>
                            <td><?php echo e($emp->tgl_lhr); ?></td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/ktp/'.$emp->scanktp)); ?>" class="image-popup" title="KTP : <?php echo e($emp->ktp); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/ktp/'.$emp->scanktp)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/sima/'.$emp->scansima)); ?>" class="image-popup" title="SIM A: <?php echo e($emp->sima); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/sima/'.$emp->scansima)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/simb/'.$emp->scansimb)); ?>" class="image-popup" title="SIM B1: <?php echo e($emp->simb1); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/simb/'.$emp->scansimb)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/simc/'.$emp->scansimc)); ?>" class="image-popup" title="SIM C: <?php echo e($emp->simc); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/simc/'.$emp->scansimc)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/npwp/'.$emp->scannpwp)); ?>" class="image-popup" title="NPWP: <?php echo e($emp->npwp); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/npwp/'.$emp->scannpwp)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/bpjs/'.$emp->scanbpjs)); ?>" class="image-popup" title="BPJS: <?php echo e($emp->bpjs); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/bpjs/'.$emp->scanbpjs)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                        </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Modal-Effect -->
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/custombox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/legacy.min.js')); ?>"></script>

    <!-- Sweet Alert Js  -->
    <script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/pages/jquery.sweet-alert.init.js')); ?>"></script>

    <!-- Magnific popup -->
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/fingerprint/jquery.timer.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/fingerprint/ajaxmask.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>

<script type="text/javascript">

    $(document).ready(function () {
        // Responsive Datatable
        $('#responsive-datatable').DataTable();

        $('.image-popup').magnificPopup({
            type: 'image',
        });
       
    });
    
    function user_register(user_id,user_name) {
				
        $('body').ajaxMask();
    
        regStats = 0;
        regCt = -1;
        try
        {
            timer_register.stop();
        }
        catch(err)	
        {
            console.log('Registration timer has been init');
        }
        
        
        var limit = 4;
        var ct = 1;
        var timeout = 5000;
        
        timer_register = $.timer(timeout, function() {					
            console.log("'"+user_name+"' registration checking...");
            user_checkregister(user_id,$("#user_finger_"+user_id).html());
            if (ct>=limit || regStats==1) 
            {
                timer_register.stop();
                console.log("'"+user_name+"' registration checking end");
                console.log(regStats);
                if (ct>=limit && regStats==0)
                {
                    alert("'"+user_name+"' registration fail!");
                    $('body').ajaxMask({ stop: true });
                }						
                if (regStats==1)
                {
                    $("#user_finger_"+user_id).html(regCt);
                    alert("'"+user_name+"' registration success!");
                    $('body').ajaxMask({ stop: true });
                    var linkText = '<a class="btn btn-secondary btn-rounded waves-effect waves-light w-md m-b-5">Fingerprint sudah terdaftar</a>';
                    $('#fingerprint'+user_id).innerHTML = linkText;
                }
            }
            ct++;
        });
    }

    function user_checkregister(user_id, current) {
        $.ajax({
            url         :   "<?php echo e(route('fingerCheckReg')); ?>",
            data        :   {
                user_id : user_id,
                current : current,
            },
            type		:	"GET",
            success		:	function(data)
                            {
                                try
                                {
                                    var res = jQuery.parseJSON(data);
                                    console.log("before: "+res.result);
                                    if (res.result)
                                    {
                                        console.log("after: "+res.result);
                                        regStats = 1;
                                        $.each(res, function(key, value){
                                            if (key=='current')
                                            {														
                                                regCt = value;
                                            }
                                        });
                                    }
                                }
                                catch(err)
                                {
                                    alert(err.message);
                                }
                            }
        });
    }

    function deleteEmployee(id){
        var token = $("meta[name='csrf-token']").attr("content");

        swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger m-l-10',
            buttonsStyling: false
        }).then(function () {
            $.ajax({
                url: "employee/"+id,
                type: 'DELETE',
                data: {
                    "id": id,
                    "_token": token,
                },
            }).done(function (data) {
                swal(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                )
                location.reload();
            }).fail(function (msg) {
                swal(
                    'Failed',
                    'Your imaginary file is safe :)',
                    'error'
                )
            });
            
        }, function (dismiss) {
            // dismiss can be 'cancel', 'overlay',
            // 'close', and 'timer'
            if (dismiss === 'cancel') {
                console.log("eh ga kehapus");
                swal(
                    'Cancelled',
                    'Your imaginary file is safe :)',
                    'error'
                )
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/employee/index.blade.php ENDPATH**/ ?>