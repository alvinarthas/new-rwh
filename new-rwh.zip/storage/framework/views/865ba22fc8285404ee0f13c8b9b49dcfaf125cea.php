<?php
    use App\DataKota;
?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- form Uploads -->
    <link href="<?php echo e(asset('assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
     <!-- Sweet Alert css -->
     <link href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- form Uploads -->
    <link href="<?php echo e(asset('assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Informasi Data Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form class="form-horizontal" role="form" action="<?php echo e(route('member.update',['id' => $member->ktp])); ?>" enctype="multipart/form-data" method="POST">
        <?php echo e(method_field('PUT')); ?>

        <?php echo csrf_field(); ?>
        
        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <h4 class="m-t-0 header-title">Profile Member</h4>
                    <p class="text-muted m-b-30 font-14">
                    </p>

                    <div class="row">
                        <div class="col-12">
                            <div class="p-20">
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Member ID</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" parsley-trigger="change" required name="member_id" id="member_id" value="<?php if(isset($member->member_id)): ?><?php echo e($member->member_id); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Nomor KTP</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" parsley-trigger="change" required name="ktp" id="ktp" value="<?php if(isset($member->ktp)): ?><?php echo e($member->ktp); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Nama Lengkap</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" parsley-trigger="change" required name="nama" id="nama" value="<?php if(isset($member->nama)): ?><?php echo e($member->nama); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Nama Ibu Kandung</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" parsley-trigger="change" required name="ibu" id="ibu" value="<?php if(isset($member->ibu)): ?><?php echo e($member->ibu); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Alamat</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" parsley-trigger="change" required name="alamat" id="alamat" value="<?php if(isset($member->alamat)): ?><?php echo e($member->alamat); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Telepon</label>
                                    <div class="col-10">
                                        <input type="number" class="form-control" parsley-trigger="change" required name="telp" id="telp" value="<?php if(isset($member->telp)): ?><?php echo e($member->telp); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Tempat Lahir</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="tempat_lahir" parsley-trigger="change" required id="tempat_lahir" value="<?php if(isset($member->tempat_lahir)): ?><?php echo e($member->tempat_lahir); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Tanggal Lahir</label>
                                    <div class="col-10">
                                        <div class="input-group">
                                            <input type="text" class="form-control" parsley-trigger="change" required placeholder="yyyy/mm/dd" name="tanggal_lahir" id="tanggal_lahir"  value="<?php if(isset($member->tgl_lahir)): ?><?php echo e($member->tgl_lahir); ?><?php endif; ?>"  data-date-format='yyyy-mm-dd'>
                                            <div class="input-group-append">
                                                <span class="input-group-text"><i class="ti-calendar"></i></span>
                                            </div>
                                        </div><!-- input-group -->
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Provinsi</label>
                                    <div class="col-10">
                                        <select class="form-control select2" parsley-trigger="change" name="prov" id="prov" onchange="getKota(this.value)">
                                            <option value="#" disabled selected>Pilih Provinsi</option>
                                            <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($member->prov)): ?>
                                                    <?php if($prov->kode_pusdatin_prov == $member->prov): ?>
                                                        <option value="<?php echo e($prov->kode_pusdatin_prov); ?>" selected><?php echo e($prov->provinsi); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($prov->kode_pusdatin_prov); ?>"><?php echo e($prov->provinsi); ?></option>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <option value="<?php echo e($prov->kode_pusdatin_prov); ?>"><?php echo e($prov->provinsi); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Kab/Kota</label>
                                    <div class="col-10">
                                        <select class="form-control select2" parsley-trigger="change" name="city" id="city">
                                            <option value="#" disabled selected>Pilih Kab/Kota</option>
                                                <?php if(isset($member->city)): ?>
                                                    <?php ($city = DataKota::getCity($member->city)); ?>
                                                    <option value="<?php echo e($city->kode_pusdatin_kota); ?>" selected><?php echo e($city->kab_kota); ?></option>
                                                <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Koordinator</label>
                                    <div class="col-10">
                                        <select class="form-control select2" parsley-trigger="change" name="koordinator" id="koordinator">
                                            <option value="#" disabled selected>Pilih Koordinator</option>
                                            <?php $__currentLoopData = $koordinator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $koor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($member->koor)): ?>
                                                    <?php if($koor->id == $member->koordinator): ?>
                                                        <option value="<?php echo e($koor->id); ?>" selected><?php echo e($koor->nama); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($koor->id); ?>"><?php echo e($koor->nama); ?></option>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <option value="<?php echo e($koor->id); ?>"><?php echo e($koor->nama); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Sub Koordinator</label>
                                    <div class="col-10">
                                        <select class="form-control select2" parsley-trigger="change" name="koordinator" id="koordinator">
                                            <option value="#" disabled selected>Pilih Sub Koordinator</option>
                                            <?php $__currentLoopData = $subkoor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($member->subkoor)): ?>
                                                    <?php if($sub->id == $member->subkoor): ?>
                                                        <option value="<?php echo e($sub->id); ?>" selected><?php echo e($sub->nama); ?></option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->nama); ?></option>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->nama); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Upload Foto KTP</label>
                                    <div class="col-10">
                                        <input type="file" class="dropify" data-height="100" name="scanktp" id="scanktp" data-default-file="<?php if(isset($member->scanktp)): ?><?php echo e(asset('assets/images/member/ktp/'.$member->scanktp)); ?><?php endif; ?>"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if(array_search("MBMBU",$page)): ?>
                        <div class="form-group text-right m-b-0">
                            <button class="btn btn-primary waves-effect waves-light" type="submit">
                                Submit
                            </button>
                        </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </form>

    
    <?php if(array_search("MBMBBV",$page)): ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Bank Member</h4>
                
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">Data Bank Member</h4>
                    <?php if(array_search("MBMBBC",$page)): ?>
                    <p class="text-muted font-14 m-b-30">
                        <a href="javascript:;" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5" onclick="funcBank('create')">Tambah Bank</a>
                    </p>
                    <?php endif; ?>

                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Bank</th>
                            <th>Nomor Rekening</th>
                            <th>No Kartu ATM</th>
                            <th>No Buku Tabungan</th>
                            <th>Cabang Pembuka</th>
                            <th>Status Rekening</th>
                            <th>Primary</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $bankmember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($bm->bank->nama); ?></td>
                                    <td><?php echo e($bm->norek); ?></td>
                                    <td><?php echo e($bm->noatm); ?></td>
                                    <td><?php echo e($bm->nobuku); ?></td>
                                    <td><?php echo e($bm->cabbank); ?></td>
                                    <td><?php echo e($bm->status); ?></td>
                                    <td><?php echo e($bm->p_status); ?></td>
                                    <td>
                                        <?php if(array_search("MBMBBU",$page)): ?>
                                        <a href="javascript:;" class="btn btn-info btn-rounded waves-effect w-md waves-info m-b-5" onclick="funcBank('edit',<?php echo e($bm->id); ?>)">Update</a>
                                        <?php endif; ?>
                                        <?php if(array_search("MBMBBD",$page)): ?>
                                        <a href="javascript:;" class="btn btn-danger btn-rounded waves-effect w-md waves-danger m-b-5" onclick="funcBank('delete',<?php echo e($bm->id); ?>)">Delete</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php ($i++); ?>
                        </tbody>
                    </table>
                </div>

                
                <div id="bankmember"></div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    
    <?php if(array_search("MBMBPV",$page)): ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Perusahaan Member</h4>
                
                <div class="card-box table-responsive" id="tblperusahaan">
                    <h4 class="m-t-0 header-title">Data Perusahaan</h4>
                    <?php if(array_search("MBMBPC",$page)): ?>
                    <p class="text-muted font-14 m-b-30">
                        <a href="javascript:;" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5" onclick="funcPerusahaan('create')">Tambah Perusahaan</a>
                    </p>
                    <?php endif; ?>
                    
                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Perusahaan</th>
                            <th>Nomor ID</th>
                            <th>Password</th>
                            <th>Action</th>
                        </thead>
    
                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $perusahaanmember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($pm->perusahaan->nama); ?></td>
                                    <td><?php echo e($pm->noid); ?></td>
                                    <td><?php echo e($pm->passid); ?></td>
                                    <td>
                                        <?php if(array_search("MBMBPU",$page)): ?>
                                            <a href="javascript:;" class="btn btn-info btn-rounded waves-effect w-md waves-info m-b-5" onclick="funcPerusahaan('edit',<?php echo e($pm->id); ?>)">Update</a>
                                        <?php endif; ?>
                                        <?php if(array_search("MBMBPD",$page)): ?>
                                            <a href="javascript:;" class="btn btn-danger btn-rounded waves-effect w-md waves-danger m-b-5" onclick="funcPerusahaan('delete',<?php echo e($pm->id); ?>)">Delete</a>
                                        <?php endif; ?>
                                        
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php ($i++); ?>
                        </tbody>
                    </table>
                </div>

                
                <div id="perusahaanmember"></div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Plugin -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- file uploads js -->
<script src="<?php echo e(asset('assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<!-- Sweet Alert Js  -->
<script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/pages/jquery.sweet-alert.init.js')); ?>"></script>
<!-- file uploads js -->
<script src="<?php echo e(asset('assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });

        var ktp = $('#ktp').val();
    </script>

    <script>
        function getKota(id){
            $.ajax({
                url : "<?php echo e(route('getDataKota')); ?>",
                type : "get",
                dataType: 'html',
                data:{
                    prov: id,
                },
            }).done(function (data) {
                $('#city').html(data);
            }).fail(function (msg) {
                alert('Gagal menampilkan data, silahkan refresh halaman.');
            });
        }
        // Date Picker
        jQuery('#tanggal_lahir').datepicker();
        jQuery('#mulai_kerja').datepicker();

        // Select2
        $(".select2").select2();
    </script>

    <script>
        // Date Picker
        jQuery('#tanggal_lahir').datepicker();
        jQuery('#mulai_kerja').datepicker();

        // Select2
        $(".select2").select2({
        });
    </script>

    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Drag and drop a file here or click',
                'replace': 'Drag and drop or click to replace',
                'remove': 'Remove',
                'error': 'Ooops, something wrong appended.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });

        function funcPerusahaan(jenis,id=null){
            if(jenis == "create"){
                $.ajax({
                    url : "<?php echo e(route('createPerusahaanMember')); ?>",
                    type : "get",
                    dataType: 'json',
                    data:{
                        ktp: ktp,
                    },
                }).done(function (data) {
                    $('#perusahaanmember').html(data);
                    element = document.getElementById("perusahaanmember");
                    element.scrollIntoView();
                }).fail(function (msg) {
                    alert('Gagal menampilkan data, silahkan refresh halaman.');
                });
            }else if(jenis == "edit"){
                $.ajax({
                    url : "<?php echo e(route('editPerusahaanMember')); ?>",
                    type : "get",
                    dataType: 'json',
                    data:{
                        ktp: ktp,
                        pid: id,
                    },
                }).done(function (data) {
                    $('#perusahaanmember').html(data);
                    element = document.getElementById("perusahaanmember");
                    element.scrollIntoView();
                }).fail(function (msg) {
                    alert('Gagal menampilkan data, silahkan refresh halaman.');
                });destroyPerusahaanMember
            }else if(jenis == "delete"){
                swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No, cancel!',
                    confirmButtonClass: 'btn btn-success',
                    cancelButtonClass: 'btn btn-danger m-l-10',
                    buttonsStyling: false
                }).then(function () {
                    $.ajax({
                        url : "<?php echo e(route('destroyPerusahaanMember')); ?>",
                        type : "get",
                        dataType: 'json',
                        data:{
                            ktp: ktp,
                            pid: id,
                        },
                    }).done(function (data) {
                        swal(
                            'Deleted!',
                            'Your file has been deleted.',
                            'success'
                        )
                        location.reload();
                    }).fail(function (msg) {
                        swal(
                            'Failed',
                            'Your imaginary file is safe :)',
                            'error'
                        )
                    });
                    
                }, function (dismiss) {
                    // dismiss can be 'cancel', 'overlay',
                    // 'close', and 'timer'
                    if (dismiss === 'cancel') {
                        console.log("eh ga kehapus");
                        swal(
                            'Cancelled',
                            'Your imaginary file is safe :)',
                            'error'
                        )
                    }
                })
            }
            
        }

        function funcBank(jenis,id=null){
            if(jenis == "create"){
                $.ajax({
                    url : "<?php echo e(route('createBankMember')); ?>",
                    type : "get",
                    dataType: 'json',
                    data:{
                        ktp: ktp,
                    },
                }).done(function (data) {
                    $('#bankmember').html(data);
                    element = document.getElementById("bankmember");
                    element.scrollIntoView();
                }).fail(function (msg) {
                    alert('Gagal menampilkan data, silahkan refresh halaman.');
                });
            }else if(jenis == "edit"){
                $.ajax({
                    url : "<?php echo e(route('editBankMember')); ?>",
                    type : "get",
                    dataType: 'json',
                    data:{
                        ktp: ktp,
                        bid: id,
                    },
                }).done(function (data) {
                    $('#bankmember').html(data);
                    element = document.getElementById("bankmember");
                    element.scrollIntoView();
                }).fail(function (msg) {
                    alert('Gagal menampilkan data, silahkan refresh halaman.');
                });destroyPerusahaanMember
            }else if(jenis == "delete"){
                swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No, cancel!',
                    confirmButtonClass: 'btn btn-success',
                    cancelButtonClass: 'btn btn-danger m-l-10',
                    buttonsStyling: false
                }).then(function () {
                    $.ajax({
                        url : "<?php echo e(route('destroyBankMember')); ?>",
                        type : "get",
                        dataType: 'json',
                        data:{
                            ktp: ktp,
                            bid: id,
                        },
                    }).done(function (data) {
                        swal(
                            'Deleted!',
                            'Your file has been deleted.',
                            'success'
                        )
                        location.reload();
                    }).fail(function (msg) {
                        swal(
                            'Failed',
                            'Your imaginary file is safe :)',
                            'error'
                        )
                    });
                    
                }, function (dismiss) {
                    // dismiss can be 'cancel', 'overlay',
                    // 'close', and 'timer'
                    if (dismiss === 'cancel') {
                        console.log("eh ga kehapus");
                        swal(
                            'Cancelled',
                            'Your imaginary file is safe :)',
                            'error'
                        )
                    }
                })
            }
            
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/member/show.blade.php ENDPATH**/ ?>