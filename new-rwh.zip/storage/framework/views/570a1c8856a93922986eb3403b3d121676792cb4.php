<?php
    use App\Perusahaan;
?>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!--venobox lightbox-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/magnific-popup/dist/magnific-popup.css')); ?>"/>

    
    <link href="<?php echo e(asset('assets/fingerprint/ajaxmask.css')); ?>" rel="stylesheet">

    <style>
    img.photo{
        display:block; width:50%; height:auto;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Index Product</h4>
                <p class="text-muted font-14 m-b-30">
                    <?php if(array_search("MDPDC",$page)): ?>
                    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Product</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('manageproduct')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Manage Harga</a>
                </p>

                <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                        <th style="width:5%">No</th>
                        <th>Supplier</th>
                        <th>Product ID</th>
                        <th>Product ID Perusahaan</th>
                        <th>Product Name</th>
                        <th>Product Brand</th>
                        <th>Stock Awal</th>
                        <th>Total Stock In</th>
                        <th>Total Stock Out</th>
                        <th>Stock Saat Ini</th>
                        <th>Actions</th>
                    </thead>

                    <tbody>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($prd->supplier()->first()->nama); ?></td>
                            <td><?php echo e($prd->prod_id); ?></td>
                            <td><?php echo e($prd->prod_id_new); ?></td>
                            <td><?php echo e($prd->name); ?></td>
                            <td><?php echo e($prd->category); ?></td>
                            <td><?php echo e($prd->stock); ?></td>
                            <td>
                                <?php ($stock_in = DB::table('tblreceivedet')->where('prod_id', $prd->prod_id)->sum('qty')); ?>
                                <?php echo e($stock_in); ?>

                            </td>
                            <td>
                                <?php ($stock_out = DB::table('tblproducttrxdet')->where('prod_id', $prd->prod_id)->sum('qty')); ?>
                                <?php echo e($stock_out); ?>

                            </td>
                            <td>
                                <?php ($sisa=$stock_in - $stock_out + $prd->stock); ?>
                                <?php echo e($sisa); ?>

                            </td>
                            <td>
                                <?php if(array_search("MDPDU",$page)): ?>
                                <a href="<?php echo e(route('product.edit', ['id' => $prd->id])); ?>" class="btn btn-custom btn-rounded waves-effect waves-light w-md m-b-5">Edit</a>
                                <?php endif; ?>
                                <?php if(array_search("MDPDD",$page)): ?>
                                <form class="" action="<?php echo e(route('product.destroy', ['id' => $prd->id])); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                    <button type="submit" class="btn btn-danger btn-rounded waves-effect waves-light w-md m-b-5">Hapus </button></a>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Modal-Effect -->
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/custombox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/legacy.min.js')); ?>"></script>

    <!-- Magnific popup -->
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/fingerprint/jquery.timer.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/fingerprint/ajaxmask.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>

<script type="text/javascript">

    $(document).ready(function () {
        // Responsive Datatable
        $('#responsive-datatable').DataTable();

        $('.image-popup').magnificPopup({
            type: 'image',
        });

    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/product/index.blade.php ENDPATH**/ ?>