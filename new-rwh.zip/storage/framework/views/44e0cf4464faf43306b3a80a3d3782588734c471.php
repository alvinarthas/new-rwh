<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data Gaji Pokok Pegawai
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('storeGajiEmp',['jenis'=>'store'])); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('storeGajiEmp',['jenis'=>'update','id' => $employee->employee_id])); ?>" enctype="multipart/form-data" method="POST">
    <?php endif; ?>

    <?php echo csrf_field(); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Gaji Pokok</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Pegawai</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="employee">
                                        <option value="#" disabled selected>Pilih Pegawai</option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($employee->employee_id)): ?>
                                                <?php if($employee2->id == $employee->employee_id): ?>
                                                    <option value="<?php echo e($employee2->id); ?>" selected><?php echo e($employee2->username); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($employee2->id); ?>" ><?php echo e($employee2->username); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($employee2->id); ?>" ><?php echo e($employee2->username); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Gaji Pokok Pegawai</label>
                                <div class="col-10">
                                    <input type="number" class="form-control" parsley-trigger="change" required name="gaji_pokok" id="gaji_pokok" value="<?php if(isset($employee->gaji_pokok)): ?><?php echo e($employee->gaji_pokok); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Tunjangan Jabatan</label>
                                <div class="col-10">
                                    <input type="number" class="form-control" parsley-trigger="change" required name="tunjangan_jabatan" id="tunjangan_jabatan" value="<?php if(isset($employee->tunjangan_jabatan)): ?><?php echo e($employee->tunjangan_jabatan); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
            // Select2
            $(".select2").select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/salary/gajipokok/form.blade.php ENDPATH**/ ?>