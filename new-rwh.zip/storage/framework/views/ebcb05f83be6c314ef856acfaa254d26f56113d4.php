<?php
    use App\Perusahaan;
    use Illuminate\Support\Facades\DB;
?>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!--venobox lightbox-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/magnific-popup/dist/magnific-popup.css')); ?>"/>

    
    <link href="<?php echo e(asset('assets/fingerprint/ajaxmask.css')); ?>" rel="stylesheet">

    <style>
    img.photo{
        display:block; width:50%; height:auto;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Data Product</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Choose Period</label>
                                <div class="col-3">
                                    <input type="month" class="form-control" parsley-trigger="change" required name="period" id="period">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group text-right m-b-0">
                    <button class="btn btn-primary waves-effect waves-light" onclick="showLog()">
                        Show
                    </button>
                </div>
            </div>
        </div>
    </div>



<div id="logTabel">

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Modal-Effect -->
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/custombox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/legacy.min.js')); ?>"></script>

    <!-- Magnific popup -->
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>

<script type="text/javascript">
    $(document).ready(function () {
        // Responsive Datatable
        $('#responsive-datatable').DataTable();
    });

    function showLog(){
            var id = $("#period").val()
            $.ajax({
                url         :   "<?php echo e(route('showProdAjx')); ?>",
                data        :   {
                    date : id,
                },
                type		:	"GET",
                dataType    :   "html",
                success		:	function(data){
                    $("#logTabel").html(data);
                },
                error       :   function(data){
                    document.getElementById('period').value = '2018-06';
                }
            });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/product/manageharga.blade.php */ ?>