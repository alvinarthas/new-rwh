<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data Modul
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('modul.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('modul.update',['id' => $modul->modul_id])); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>

    <?php echo csrf_field(); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Tambah Modul</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Modul ID</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="modul_id" id="modul_id" value="<?php if(isset($modul->modul_id)): ?><?php echo e($modul->modul_id); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Modul Description</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="modul_desc" id="modul_desc" value="<?php if(isset($modul->modul_desc)): ?><?php echo e($modul->modul_desc); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Modul Icon</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="modul_icon" id="modul_icon" value="<?php if(isset($modul->modul_icon)): ?><?php echo e($modul->modul_icon); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\rwh\resources\views/modul/form.blade.php */ ?>