<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- form Uploads -->
    <link href="<?php echo e(asset('assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data Koordinator Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('koordinator.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('koordinator.update',['id' => $koordinator->id])); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>

    <?php echo csrf_field(); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Data Koordinator Member</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nama</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="nama" id="nama" value="<?php if(isset($koordinator->nama)): ?><?php echo e($koordinator->nama); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Alamat</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="alamat" id="alamat" value="<?php if(isset($koordinator->alamat)): ?><?php echo e($koordinator->alamat); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor Telepon</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="telp" id="telp" value="<?php if(isset($koordinator->telp)): ?><?php echo e($koordinator->telp); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor KTP</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="ktp" id="ktp" value="<?php if(isset($koordinator->ktp)): ?><?php echo e($koordinator->ktp); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <h4 class="m-t-0 header-title">Masukan Member ID <a href=""><< Masukan Member ID >></a> </h4>
                <p class="text-muted m-b-30 font-14"></p>
                <div class = "row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Member ID</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="memberid" id="memberid" value="<?php if(isset($koordinator->memberid)): ?><?php echo e($koordinator->memberid); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Plugin -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- file uploads js -->
<script src="<?php echo e(asset('assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });
    </script>

    <script>
        // Date Picker
        jQuery('#tanggal_lahir').datepicker();
        jQuery('#mulai_kerja').datepicker();

        // Select2
        $(".select2").select2({
            templateResult: formatState,
            templateSelection: formatState
        });

        function formatState (opt) {
            if (!opt.id) {
                return opt.text.toUpperCase();
            }

            var optimage = $(opt.element).attr('data-image');
            console.log(optimage)
            if(!optimage){
            return opt.text.toUpperCase();
            } else {
                var $opt = $(
                '<span><img src="' + optimage + '" width="60px" /> ' + opt.text.toUpperCase() + '</span>'
                );
                return $opt;
            }
        };

    </script>

    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Drag and drop a file here or click',
                'replace': 'Drag and drop or click to replace',
                'remove': 'Remove',
                'error': 'Ooops, something wrong appended.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/koordinator/form.blade.php */ ?>