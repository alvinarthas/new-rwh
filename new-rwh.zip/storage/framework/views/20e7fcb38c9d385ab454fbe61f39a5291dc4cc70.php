<div class="card-box table-responsive">
    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <th>No</th>
            <th>Jurnal ID</th>
            <th>Transaction Date</th>
            <th>Account Number</th>
            <th>Account Name</th>
            <th>Debet</th>
            <th>Credit</th>
            <th>Notes</th>
            <th>Description</th>
            <th>Option</th>
        </thead>
        <tbody>
            <?php echo csrf_field(); ?>
            <?php ($i=1); ?>
            <?php $__currentLoopData = $jurnals['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($jurnal->id_jurnal); ?></td>
                    <td><?php echo e($jurnal->date); ?></td>
                    <td><?php echo e($jurnal->AccNo); ?></td>
                    <td><?php echo e($jurnal->coa->AccName); ?></td>
                    <?php if($jurnal->AccPos == "Debet"): ?>
                        <td>Rp. <?php echo e(number_format($jurnal->Amount)); ?></td>
                    <?php else: ?> <td></td> <?php endif; ?>
                    <?php if($jurnal->AccPos == "Credit"): ?>
                        <td>Rp. <?php echo e(number_format($jurnal->Amount)); ?></td>
                    <?php else: ?> <td></td> <?php endif; ?>
                    <td><?php echo e($jurnal->notes_item); ?></td>
                    <td><?php echo e($jurnal->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('jurnal.edit',['id'=>$jurnal->id_jurnal])); ?>" class="btn btn-info btn-rounded waves-effect w-md waves-danger m-b-5" >Update</a>
                        <a href="javascript:;" onclick="jurnalDelete(<?php echo e($jurnal->id_jurnal); ?>)" class="btn btn-info btn-rounded waves-effect w-md waves-danger m-b-5" >Delete</a>
                    </td>
                </tr>
            <?php ($i++); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="card-box">
    <h4 class="m-t-0 header-title">Total Jurnal</h4>
    <div class="col-12">
        <div class="p-20">
            <div class="form-group row">
                <label class="col-2 col-form-label">Total Debet</label>
                <div class="col-10">
                    <input type="text" class="form-control" parsley-trigger="change" value="Rp. <?php echo e(number_format($jurnals['ttl_debet'])); ?>" readonly>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-2 col-form-label">Total Credit</label>
                <div class="col-10">
                    <input type="text" class="form-control" parsley-trigger="change" value="Rp. <?php echo e(number_format($jurnals['ttl_credit'])); ?>" readonly>
                </div>
            </div>
        </div>
    </div>
</div>
    
<script>
// Responsive Datatable
$('#responsive-datatable').DataTable();

function jurnalDelete(id){
    function deletePurchase(id){
        var token = $("meta[name='csrf-token']").attr("content");

        swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger m-l-10',
            buttonsStyling: false
        }).then(function () {
            $.ajax({
                url: "jurnal/"+id,
                type: 'DELETE',
                data: {
                    "id": id,
                    "_token": token,
                },
            }).done(function (data) {
                swal(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                )
                location.reload();
            }).fail(function (msg) {
                swal(
                    'Failed',
                    'Your imaginary file is safe :)',
                    'error'
                )
            });
            
        }, function (dismiss) {
            // dismiss can be 'cancel', 'overlay',
            // 'close', and 'timer'
            if (dismiss === 'cancel') {
                swal(
                    'Cancelled',
                    'Your imaginary file is safe :)',
                    'error'
                )
            }
        })
    }
}
</script>
    <?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/jurnal/view.blade.php ENDPATH**/ ?>