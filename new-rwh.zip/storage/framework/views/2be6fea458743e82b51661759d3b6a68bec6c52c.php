<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!--venobox lightbox-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/magnific-popup/dist/magnific-popup.css')); ?>"/>
    <!--select2-->
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <!--datepicker-->
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!--Token-->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    use App\Coa;
?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">

                <?php if($bonusapa=="perhitungan" OR $bonusapa=="bonusgagal"): ?>
                    <?php if($bonusapa=="perhitungan"): ?>
                        <h3 class="m-t-0 header-title">Perhitungan Bonus Member</h3>
                        <?php if(array_search("BMPBC",$page)): ?>
                            <?php if($jenis == "index"): ?>
                                <p class="text-muted font-14 m-b-30">
                                    <a href="<?php echo e(route('bonus.create')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Perhitungan Bonus</a>
                                </p>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php elseif($bonusapa=="bonusgagal"): ?>
                        <h3 class="m-t-0 header-title">Laporan Upload Gagal Perhitungan Bonus Member</h3>
                    <?php endif; ?>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Nama Perusahaan</label>
                        <div class="col-10">
                            <select class="form-control select2" parsley-trigger="change" id="perusahaan" name="perusahaan">
                                <option value="#" disabled selected>Pilih Perusahaan</option>
                                <?php $__currentLoopData = $perusahaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($prs->id); ?>"><?php echo e($prs->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                <?php elseif($bonusapa=="pembayaran" OR $bonusapa=="topup"): ?>
                    <?php if($bonusapa=="pembayaran"): ?>
                        <h3 class="m-t-0 header-title">Pembayaran Bonus Member</h3>
                    <?php elseif($bonusapa=="topup"): ?>
                        <h3 class="m-t-0 header-title">Top Up Bonus Member</h3>
                    <?php endif; ?>
                    <?php if($jenis == "index"): ?>
                        <?php if($bonusapa=="pembayaran"): ?>
                            <?php if(array_search("BMBBC",$page)): ?>
                                <p class="text-muted font-14 m-b-30">
                                    <a href="<?php echo e(route('bonus.createbayar')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Pembayaran Bonus</a>
                                </p>
                            <?php endif; ?>
                        <?php elseif($bonusapa=="topup"): ?>
                            <?php if(array_search("BMTUC",$page)): ?>
                                <p class="text-muted font-14 m-b-30">
                                    <a href="<?php echo e(route('bonus.createtopup')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Top Up Bonus Member</a>
                                </p>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Tanggal Transaksi</label>
                        <div class="col-10">
                            <div class="input-group">
                                <input type="text" class="form-control" parsley-trigger="change" required placeholder="YYYY/MM/DD" name="tgl_transaksi" id="tgl_transaksi"  value=""  data-date-format='yyyy-mm-dd' autocomplete="off">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-calendar"></i></span>
                                </div>
                            </div><!-- input-group -->
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($bonusapa=="perhitungan" OR $bonusapa=="pembayaran" OR $bonusapa=="laporan" OR $bonusapa=="bonusgagal"): ?>
                    <?php if($bonusapa=="laporan"): ?>
                        <h3 class="m-t-0 header-title">Laporan Realisasi Bonus Member</h3>
                    <?php endif; ?>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Bulan & Tahun Bonus</label>
                        <div class="col-5">
                            <select class="form-control select2" parsley-trigger="change" name="bulan" id="bulan" required>
                                <option value="#" selected disabled>Pilih Bulan</option>
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e(date("F", mktime(0, 0, 0, $i, 10))); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-5">
                            <select class="form-control select2" parsley-trigger="change" name="tahun" id="tahun" required>
                                <option value="#" selected disabled>Pilih Tahun</option>
                                <?php for($i = 2018; $i <= date('Y'); $i++): ?>
                                    <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($bonusapa=="pembayaran" OR $bonusapa=="topup"): ?>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Rekening Bank Tujuan</label>
                        <div class="col-10">
                            <select class="form-control" parsley-trigger="change" id="rekening" name="rekening">
                            </select>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="form-group text-right m-b-0">
        <?php if($bonusapa=="perhitungan"): ?>
            <?php if($jenis=="index"): ?>
                <button class="btn btn-primary waves-effect waves-light" onclick="showBonusPerhitungan()" type="submit">
                    Show Bonus
                </button>
            <?php elseif($jenis=="create"): ?>
                <a href="<?php echo e(route('bonus.index')); ?>"><button class="btn btn-warning waves-effect waves-light" type="submit">
                    Back
                </button></a>
                <button class="btn btn-primary waves-effect waves-light" onclick="createBonusPerhitungan()" type="submit">
                    Create Bonus
                </button>
            <?php endif; ?>
        <?php elseif($bonusapa=="pembayaran"): ?>
            <?php if($jenis=="index"): ?>
                <button class="btn btn-primary waves-effect waves-light" onclick="showBonusPembayaran()" type="submit">
                    Show Bonus
                </button>
            <?php elseif($jenis=="create"): ?>
                <a href="<?php echo e(route('bonus.bayar')); ?>"><button class="btn btn-warning waves-effect waves-light" type="submit">
                    Back
                </button></a>
                <button class="btn btn-primary waves-effect waves-light" onclick="createBonusPembayaran()" type="submit">
                    Create Bonus
                </button>
            <?php endif; ?>
        <?php elseif($bonusapa=="topup"): ?>
            <?php if($jenis=="index"): ?>
                <button class="btn btn-primary waves-effect waves-light" onclick="showBonusTopup()" type="submit">
                    Show Bonus
                </button>
            <?php elseif($jenis=="create"): ?>
                <a href="<?php echo e(route('bonus.topup')); ?>"><button class="btn btn-warning waves-effect waves-light" type="submit">
                    Back
                </button></a>
                <button class="btn btn-primary waves-effect waves-light" onclick="createBonusTopup()" type="submit">
                    Create Bonus
                </button>
            <?php endif; ?>
        <?php elseif($bonusapa=="laporan"): ?>
            <?php if($jenis=="index"): ?>
                <button class="btn btn-primary waves-effect waves-light" onclick="showLaporanBonus()" type="submit">
                    Show Bonus
                </button>
            <?php endif; ?>
        <?php elseif($bonusapa=="bonusgagal"): ?>
            <?php if($jenis=="index"): ?>
                <button class="btn btn-primary waves-effect waves-light" onclick="showLaporanBonusGagal()" type="submit">
                    Show Bonus
                </button>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <div id="tblBonus">

    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Modal-Effect -->
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/custombox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/legacy.min.js')); ?>"></script>

    <!-- Magnific popup -->
    <script type="text/javascript" src="<?php echo e(asset('assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>

    <!-- Select2 -->
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>

    <!-- number-divider -->
    <script src="<?php echo e(asset('assets/plugins/number-divider/number-divider.min.js')); ?>"></script>

    <!-- Datepicker -->
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>

<script type="text/javascript">

    $(document).ready(function () {
        ajx_coa();
        jQuery('#tgl_transaksi').datepicker();
        // Responsive Datatable
        $('#responsive-datatable').DataTable();

        $('.image-popup').magnificPopup({
            type: 'image',
        });

        // Select2
        $("#bulan").select2({
            templateResult: formatState,
            templateSelection: formatState
        });
        $("#tahun").select2({
            templateResult: formatState,
            templateSelection: formatState
        });
        $("#perusahaan").select2({
            templateResult: formatState,
            templateSelection: formatState
        });

        function formatState (opt) {
            if (!opt.id) {
                return opt.text.toUpperCase();
            }

            var optimage = $(opt.element).attr('data-image');
            if(!optimage){
            return opt.text.toUpperCase();
            } else {
                var $opt = $(
                '<span><img src="' + optimage + '" width="60px" /> ' + opt.text.toUpperCase() + '</span>'
                );
                return $opt;
            }
        };

    });

    function ajx_coa(){
        $("#rekening").select2({
            placeholder:'Masukan Kata Kunci',
            ajax:{
                url: "<?php echo e(route('ajxCoaOrder')); ?>",
                dataType:'json',
                delay:250,
                data:function(params){
                    return{
                        keyword:params.term,
                    };
                },
                processResults:function(data){
                    var item = $.map(data, (value)=>{ //map buat ngemap object data kyk foreach
                        return { id: value.id, text: value.AccName};
                    });
                    return {
                        results: item
                    }
                },
                cache: false,
            },
            minimumInputLength: 3,
            // templateResult: formatRepo,
            // templateSelection: formatRepoSelection
        });
    }

    function showBonusPerhitungan(){
            var bln = $("#bulan").val()
            var thn = $("#tahun").val()
            var perusahaan = $("#perusahaan").val()
            $.ajax({
                url         :   "<?php echo e(route('showBonusPerhitungan')); ?>",
                data        :   {
                    tahun : thn,
                    bulan : bln,
                    perusahaan : perusahaan,
                },
                type		:	"GET",
                dataType    :   "html",
                success		:	function(data){
                    $("#tblBonus").html(data);
                },
                error       :   function(data){
                    document.getElementById('tahun').value = '2018';
                }
            });
    }

    function createBonusPerhitungan(){
            var bln = $("#bulan").val()
            var thn = $("#tahun").val()
            var perusahaan = $("#perusahaan").val()
            $.ajax({
                url         :   "<?php echo e(route('createBonusPerhitungan')); ?>",
                data        :   {
                    tahun : thn,
                    bulan : bln,
                    perusahaan : perusahaan,
                },
                type		:	"GET",
                dataType    :   "html",
                success		:	function(data){
                    $("#tblBonus").html(data);
                },
                error       :   function(data){
                    document.getElementById('tahun').value = '2016';
                }
            });
    }

    function showBonusPembayaran(){
        var tgl = $("#tgl_transaksi").val()
        var bln = $("#bulan").val()
        var thn = $("#tahun").val()
        var rekening = $("#rekening").val()
        $.ajax({
            url         :   "<?php echo e(route('showBonusPembayaran')); ?>",
            data        :   {
                tgl : tgl,
                tahun : thn,
                bulan : bln,
                rkng : rekening,
            },
            type		:	"GET",
            dataType    :   "html",
            success		:	function(data){
                $("#tblBonus").html(data);
            },
            error       :   function(data){
                document.getElementById('tgl_transaksi').value = '1945-08-17';
            }
        });
    }

    function createBonusPembayaran(){
        var tgl = $("#tgl_transaksi").val()
        var bln = $("#bulan").val()
        var thn = $("#tahun").val()
        var rekening = $("#rekening").val()
        $.ajax({
            url         :   "<?php echo e(route('createBonusPembayaran')); ?>",
            data        :   {
                tgl : tgl,
                tahun : thn,
                bulan : bln,
                rkng : rekening,
            },
            type		:	"GET",
            dataType    :   "html",
            success		:	function(data){
                $("#tblBonus").html(data);
            },
            error       :   function(data){
                document.getElementById('tgl_transaksi').value = '1945-08-17';
            }
        });
    }

    function showBonusTopup(){
        var tgl = $("#tgl_transaksi").val()
        var rekening = $("#rekening").val()
        $.ajax({
            url         :   "<?php echo e(route('showBonusTopup')); ?>",
            data        :   {
                tgl : tgl,
                rkng : rekening,
            },
            type		:	"GET",
            dataType    :   "html",
            success		:	function(data){
                $("#tblBonus").html(data);
            },
            error       :   function(data){
                document.getElementById('tgl_transaksi').value = '1945-08-17';
            }
        });
    }

    function createBonusTopup(){
        var tgl = $("#tgl_transaksi").val()
        var rekening = $("#rekening").val()
        $.ajax({
            url         :   "<?php echo e(route('createBonusTopup')); ?>",
            data        :   {
                tgl : tgl,
                rkng : rekening,
            },
            type		:	"GET",
            dataType    :   "html",
            success		:	function(data){
                $("#tblBonus").html(data);
            },
            error       :   function(data){
                document.getElementById('tgl_transaksi').value = '1945-08-17';
            }
        });
    }

    function showLaporanBonus(){
        var bln = $("#bulan").val()
        var thn = $("#tahun").val()
        $.ajax({
            url         :   "<?php echo e(route('showLaporanBonus')); ?>",
            data        :   {
                bulan : bln,
                tahun : thn,
            },
            type		:	"GET",
            dataType    :   "html",
            success		:	function(data){
                $("#tblBonus").html(data);
            },
            error       :   function(data){
                document.getElementById('tahun').value = '2018';
            }
        });
    }

    function showLaporanBonusGagal(){
        var bln = $("#bulan").val()
        var thn = $("#tahun").val()
        var perusahaan = $("#perusahaan").val()
        $.ajax({
            url         :   "<?php echo e(route('showLaporanBonusGagal')); ?>",
            data        :   {
                bulan : bln,
                tahun : thn,
                prshn : perusahaan,
            },
            type		:	"GET",
            dataType    :   "html",
            success		:	function(data){
                $("#tblBonus").html(data);
            },
            error       :   function(data){
                document.getElementById('tahun').value = '2018';
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/bonus/index.blade.php ENDPATH**/ ?>