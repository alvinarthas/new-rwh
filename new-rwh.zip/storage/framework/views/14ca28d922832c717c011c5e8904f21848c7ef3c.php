<div class="card-box table-responsive">
    <h4 class="m-t-0 header-title">Periode Poin: <?php echo e($start); ?> - <?php echo e($end); ?></h4>
    <p class="text-muted font-14 m-b-30">
        <?php echo e($nama); ?>

    </p>

    <table id="modal-table" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <th>No</th>
            <th>Tanggal</th>
            <th>Jumlah Poin</th>
            <th>Input By</th>
            <th>Action</th>
        </thead>

        <tbody>
            <?php ($i = 1); ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($data['date']); ?></td>
                <td><?php echo e($data['poin']); ?></td>
                <td><?php echo e($data['creator']); ?></td>
                <td>
                    <?php if(array_search("EMEPD",$page)): ?>
                        <a href="javascript:;" class="btn btn-danger btn-rounded waves-effect w-md waves-danger m-b-5" onclick="deletePoin(<?php echo e($data['id']); ?>)"><i class="fa fa-file-pdf-o"></i>Delete Poin</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php ($i++); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script>
// Responsive Datatable
$('#modal-table').DataTable();
</script><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/salary/poin/detail.blade.php ENDPATH**/ ?>