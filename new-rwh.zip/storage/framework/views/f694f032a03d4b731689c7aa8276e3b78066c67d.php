<?php
    use App\BankMember;
    $i=1;
?>
<div id="load" class="table-responsive">
    <table class="table m-b-0">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Gambar KTP</th>
                <th>Gambar Tabungan</th>
                <th>Gambar ATM</th>
                <th>Status Rekening</th>
                <th>Status Cetak</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td><a href="<?php echo e(route('member.show',['id' => $data->ktp])); ?>"><?php echo e($data->nama); ?></a></td>
                
                <?php if($data->scanktp == "noimage.jpg" || $data->scanktp == ''): ?>
                    <td>Empty</td>
                <?php else: ?>
                    <td>Have Filled</td>
                <?php endif; ?>
                
                <?php ($tabungan = BankMember::getData($data->ktp)); ?>

                <?php if($tabungan <> NULL): ?>
                    <?php if($tabungan->scantabungan == "noimage.jpg"): ?>
                        <td>Empty</td>
                    <?php else: ?>
                        <td>Have Filled</td>
                    <?php endif; ?>
                    <?php if($tabungan->scanatm == "noimage.jpg"): ?>
                        <td>Empty</td>
                    <?php else: ?>
                        <td>Have Filled</td>
                    <?php endif; ?>

                    <td>Aktif</td>
                <?php else: ?>
                    <td>No Primary</td>
                    <td>No Primary</td>
                    <td>Tidak Aktif</td>
                <?php endif; ?>
                <?php if($data->cetak == 0): ?>
                    <td>Belum dicetak</td>
                <?php else: ?>
                    <td>Sudah Dicetak</td>
                <?php endif; ?>
                <?php ($i++); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
    <?php echo e($datas->links()); ?> 
</div>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/member/list.blade.php */ ?>