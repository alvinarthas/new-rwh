<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
    <meta name="author" content="Coderthemes">

    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/rwh.ico')); ?>">

    <title>Royal Warehouse - Enterprise Resource Planning -</title>
    
    <?php echo $__env->yieldContent('css'); ?>
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />
    
    <script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>

</head>
<?php /* C:\xampp\htdocs\rwh\resources\views/layout/head.blade.php */ ?>