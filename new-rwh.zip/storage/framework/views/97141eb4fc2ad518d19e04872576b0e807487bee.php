<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Index COA</h4>
                <p class="text-muted font-14 m-b-30">
                    <a href="<?php echo e(route('coa.create')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Modul</a>
                </p>

                <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                        <th>No</th>
                        <th>Account Group</th>
                        <th>Account Number</th>
                        <th>Account Name</th>
                        <th>Posisi Saldo Normal</th>
                        <th>Status Account</th>
                        <th>Account Parent</th>
                        <th>Normal Saldo Normal</th>
                        <th>Action</th>
                    </thead>

                    <tbody>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $coa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($item->grup->grup); ?></td>
                            <td><?php echo e($item->AccNo); ?></td>
                            <td><?php echo e($item->AccName); ?></td>
                            <td><?php echo e($item->SaldoNormal); ?></td>
                            <td><?php echo e($item->StatusAccount); ?></td>
                            <td><?php echo e($item->AccParent); ?></td>
                            <td><?php echo e($item->SaldoAwal); ?></td>
                            <td>
                                <a href="<?php echo e(route('coa.edit',['id'=>$item->id])); ?>" class="btn btn-custom btn-rounded waves-effect waves-light w-md m-b-5">Edit</a>
                                <form class="" action="<?php echo e(route('coa.destroy', ['id' => $item->id])); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                    <button type="submit" class="btn btn-danger btn-rounded waves-effect waves-light w-md m-b-5">Hapus </button></a>
                                </form>
                            </td>
                        </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<script type="text/javascript">

    $(document).ready(function () {

        // Responsive Datatable
        $('#responsive-datatable').DataTable();
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/coa/index.blade.php ENDPATH**/ ?>