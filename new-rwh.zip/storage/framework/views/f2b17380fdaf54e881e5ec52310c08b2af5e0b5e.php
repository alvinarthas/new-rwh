<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- form Uploads -->
    <link href="<?php echo e(asset('assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('product.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('product.update', ['id' => $product->id])); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>

    <?php echo csrf_field(); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Data Product</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Company Name</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="company_id">
                                        <option value="#" disabled selected>Pilih Company</option>
                                        <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($product->company_id)): ?>
                                                <?php if($cmp->company_id == $product->company_id): ?>
                                                    <option value="<?php echo e($cmp->company_id); ?>" selected><?php echo e($cmp->company_name); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($cmp->company_id); ?>" ><?php echo e($cmp->company_name); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($cmp->company_id); ?>" ><?php echo e($cmp->company_name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Product ID</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="prod_id" id="prod_id" value="<?php if(isset($product->prod_id)): ?><?php echo e($product->prod_id); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Product Name</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="name" id="name" value="<?php if(isset($product->name)): ?><?php echo e($product->name); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Product Brand</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="category" id="category" value="<?php if(isset($product->category)): ?><?php echo e($product->category); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Supplier</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="supplier">
                                        <option value="#" disabled selected>Pilih Supplier</option>
                                        <?php $__currentLoopData = $perusahaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($product->supplier)): ?>
                                                <?php if($prs->nama == $product->supplier): ?>
                                                    <option value="<?php echo e($prs->nama); ?>" selected><?php echo e($prs->nama); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($prs->nama); ?>" ><?php echo e($prs->nama); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($prs->nama); ?>" ><?php echo e($prs->nama); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php if($jenis == "edit"): ?>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Stock Awal</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" parsley-trigger="change" required name="stock" id="stock" value="<?php if(isset($product->stock)): ?><?php echo e($product->stock); ?><?php endif; ?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="card-box">
                                            <h4 class="m-t-0 header-title">Product ID Perusahaan</h4>
                                            <p class="text-muted m-b-30 font-14"></p>
                                            <div class="form-group row">
                                                <label class="col-2 col-form-label">Product ID Perusahaan</label>
                                                <div class="col-10">
                                                    <input type="text" class="form-control" parsley-trigger="change" name="prod_id_new" id="prod_id_new" value="<?php if(isset($product->prod_id_new)): ?><?php echo e($product->prod_id_new); ?><?php endif; ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Plugin -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- file uploads js -->
<script src="<?php echo e(asset('assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });
    </script>

    <script>
        // Date Picker
        jQuery('#tanggal_lahir').datepicker();
        jQuery('#mulai_kerja').datepicker();

        // Select2
        $(".select2").select2({
            templateResult: formatState,
            templateSelection: formatState
        });

        function formatState (opt) {
            if (!opt.id) {
                return opt.text.toUpperCase();
            }

            var optimage = $(opt.element).attr('data-image');
            console.log(optimage)
            if(!optimage){
            return opt.text.toUpperCase();
            } else {
                var $opt = $(
                '<span><img src="' + optimage + '" width="60px" /> ' + opt.text.toUpperCase() + '</span>'
                );
                return $opt;
            }
        };

    </script>

    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Drag and drop a file here or click',
                'replace': 'Drag and drop or click to replace',
                'remove': 'Remove',
                'error': 'Ooops, something wrong appended.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/product/form.blade.php */ ?>