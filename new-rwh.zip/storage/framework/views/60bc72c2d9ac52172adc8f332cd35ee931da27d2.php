<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- form Uploads -->
    <link href="<?php echo e(asset('assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data Pegawai
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('employee.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('employee.update',['id' => $employee->id])); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>

    <?php echo csrf_field(); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi Pribadi</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nama Lengkap</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="nama" id="nama" value="<?php if(isset($employee->name)): ?><?php echo e($employee->name); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor Induk Pegawai</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="nip" id="nip" value="<?php if(isset($employee->nip)): ?><?php echo e($employee->nip); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Alamat</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="alamat" id="alamat" value="<?php if(isset($employee->address)): ?><?php echo e($employee->address); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Telepon</label>
                                <div class="col-10">
                                    <input type="number" class="form-control" parsley-trigger="change" required name="telepon" id="telepon" value="<?php if(isset($employee->phone)): ?><?php echo e($employee->phone); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">E-mail</label>
                                <div class="col-10">
                                    <input type="email" class="form-control" parsley-trigger="change" required name="email" id="email" value="<?php if(isset($employee->email)): ?><?php echo e($employee->email); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Tempat Lahir</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="tempat_lahir" parsley-trigger="change" required id="tempat_lahir" value="<?php if(isset($employee->tmpt_lhr)): ?><?php echo e($employee->tmpt_lhr); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Tanggal Lahir</label>
                                <div class="col-10">
                                    <div class="input-group">
                                        <input type="text" class="form-control" parsley-trigger="change" required placeholder="yyyy/mm/dd" name="tanggal_lahir" id="tanggal_lahir"  value="<?php if(isset($employee->tgl_lhr)): ?><?php echo e($employee->tgl_lhr); ?><?php endif; ?>"  data-date-format='yyyy-mm-dd' autocomplete="off">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><i class="ti-calendar"></i></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Mulai Bekerja</label>
                                <div class="col-10">
                                    <div class="input-group">
                                        <input type="text" class="form-control" parsley-trigger="change" required placeholder="yyyy/mm/dd" name="mulai_kerja" id="mulai_kerja"  value="<?php if(isset($employee->mulai_kerja)): ?><?php echo e($employee->mulai_kerja); ?><?php endif; ?>" data-date-format='yyyy-mm-dd' autocomplete="off">
                                        <div class="input-group-append">
                                            <span class="input-group-text"><i class="ti-calendar"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload Foto Personal</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scanfoto" id="scanfoto" data-default-file="<?php if(isset($employee->scanfoto)): ?><?php echo e(asset('assets/images/employee/foto/'.$employee->scanfoto)); ?><?php endif; ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php if($jenis=="create"): ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi Akun</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Username</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="username" id="username" parsley-trigger="change" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Password</label>
                                <div class="col-10">
                                    <input type="password" class="form-control" name="password" id="password" parsley-trigger="change" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi Tabungan</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Bank</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="bank">
                                        <option value="#" disabled selected>Pilih Bank</option>
                                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bank->kode); ?>" data-image="<?php echo e(asset('assets/images/bank/'.$bank->icon)); ?>"><?php echo e($bank->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor Rekening</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="rekening" id="rekening" parsley-trigger="change" value="<?php if(isset($employee->norek)): ?><?php echo e($employee->norek); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi KTP</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor KTP</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="ktp" id="ktp" value="<?php if(isset($employee->ktp)): ?><?php echo e($employee->ktp); ?><?php endif; ?>" parsley-trigger="change" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload KTP</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scanktp" id="scanktp" data-default-file="<?php if(isset($employee->scanktp)): ?><?php echo e(asset('assets/images/employee/ktp/'.$employee->scanktp)); ?><?php endif; ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi SIM A</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor SIM A</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="sima" id="sima" value="<?php if(isset($employee->sima)): ?><?php echo e($employee->sima); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload SIM A</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scansima" id="scansima" data-default-file="<?php if(isset($employee->scansima)): ?><?php echo e(asset('assets/images/sima/'.$employee->scansima)); ?><?php endif; ?>"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi SIM C</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor SIM C</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="simc" id="simc" value="<?php if(isset($employee->simc)): ?><?php echo e($employee->simc); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload SIMC</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scansimc" id="scansimc" data-default-file="<?php if(isset($employee->scansimc)): ?><?php echo e(asset('assets/images/employee/simc/'.$employee->scansimc)); ?><?php endif; ?>"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi SIM B1</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor SIM B1</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="simb" id="simb" value="<?php if(isset($employee->simb)): ?><?php echo e($employee->simb); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload sIM B1</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scansimb" id="scansimb" data-default-file="<?php if(isset($employee->scansimb)): ?><?php echo e(asset('assets/images/employee/simb/'.$employee->scansimb)); ?><?php endif; ?>" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi NPWP</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor NPWP</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="npwp" id="npwp" value="<?php if(isset($employee->npwp)): ?><?php echo e($employee->npwp); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload NPWP</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scannpwp" id="scannpwp" data-default-file="<?php if(isset($employee->scannpwp)): ?><?php echo e(asset('assets/images/employee/npwp/'.$employee->scannpwp)); ?><?php endif; ?>"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi BPJS</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor BPJS</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="bpjs" id="bpjs" value="<?php if(isset($employee->bpjs)): ?><?php echo e($employee->bpjs); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload BPJS</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scanbpjs" id="scanbpjs" data-default-file="<?php if(isset($employee->scanbpjs)): ?><?php echo e(asset('assets/images/employee/bpjs/'.$employee->scanbpjs)); ?><?php endif; ?>"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Plugin -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- file uploads js -->
<script src="<?php echo e(asset('assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });
    </script>

    <script>
        // Date Picker
        jQuery('#tanggal_lahir').datepicker();
        jQuery('#mulai_kerja').datepicker();

        // Select2
        $(".select2").select2({
            templateResult: formatState,
            templateSelection: formatState
        });

        function formatState (opt) {
            if (!opt.id) {
                return opt.text.toUpperCase();
            } 

            var optimage = $(opt.element).attr('data-image'); 
            console.log(optimage)
            if(!optimage){
            return opt.text.toUpperCase();
            } else {                    
                var $opt = $(
                '<span><img src="' + optimage + '" width="60px" /> ' + opt.text.toUpperCase() + '</span>'
                );
                return $opt;
            }
        };

    </script>

    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Drag and drop a file here or click',
                'replace': 'Drag and drop or click to replace',
                'remove': 'Remove',
                'error': 'Ooops, something wrong appended.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/employee/form.blade.php ENDPATH**/ ?>