<?php if($jenis == "create"): ?>
    <form class="form-horizontal" role="form" action="<?php echo e(route('storePerusahaanMember',['ktp' => $ktp])); ?>" enctype="multipart/form-data" method="POST">
<?php elseif($jenis == "edit"): ?>
    <form class="form-horizontal" role="form" action="<?php echo e(route('updatePerusahaanMember',['ktp' => $ktp,'pid'=>$perid->id])); ?>" enctype="multipart/form-data" method="POST">
        <?php echo e(method_field('PUT')); ?>

<?php endif; ?>

<?php echo csrf_field(); ?>
    <div class="card-box">
        <h4 class="m-t-0 header-title">Form Perusahaan Member</h4>
        <div class="row">
            <div class="col-12">
                <div class="p-20">
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Nama Perusahaan</label>
                        <div class="col-10">
                            <select class="form-control select2" parsley-trigger="change" name="perusahaan" id="perusahaan">
                                <option value="#" disabled selected>Pilih Perusahaan</option>
                                <?php $__currentLoopData = $perusahaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($perid->perusahaan_id)): ?>
                                        <?php if($per->id == $perid->perusahaan_id): ?>
                                            <option value="<?php echo e($per->id); ?>" selected><?php echo e($per->nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($per->id); ?>"><?php echo e($per->nama); ?></option>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <option value="<?php echo e($per->id); ?>"><?php echo e($per->nama); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Nomor ID</label>
                        <div class="col-10">
                            <input type="text" class="form-control" parsley-trigger="change" required name="nomorid" id="nomorid" value="<?php if(isset($perid->noid)): ?><?php echo e($perid->noid); ?><?php endif; ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Password</label>
                        <div class="col-10">
                            <input type="text" class="form-control" parsley-trigger="change" required name="password" id="password" value="<?php if(isset($perid->passid)): ?><?php echo e($perid->passid); ?><?php endif; ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-2 col-form-label">Posisi</label>
                        <div class="col-10">
                            <input type="text" class="form-control" parsley-trigger="change" required name="posisi" id="posisi" value="<?php if(isset($perid->posisi)): ?><?php echo e($perid->posisi); ?><?php endif; ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </div>
</form>

<script>
    // Select2
    $(".select2").select2({});
</script>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/member/perusahaanmember/form.blade.php */ ?>