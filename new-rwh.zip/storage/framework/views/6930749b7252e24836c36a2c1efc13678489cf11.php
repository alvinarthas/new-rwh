<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data SubModul
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('submodul.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('submodul.update',['id' => $sub->submodul_id])); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>

    <?php echo csrf_field(); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Tambah SubModul</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Modul</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="modul_id">
                                        <option value="#" disabled selected>Pilih Modul</option>
                                        <?php $__currentLoopData = $moduls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($sub->modul_id)): ?>
                                                <?php if($sub->modul_id == $modul->modul_id): ?>
                                                    <option value="<?php echo e($modul->modul_id); ?>" selected><?php echo e($modul->modul_desc); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($modul->modul_id); ?>"><?php echo e($modul->modul_desc); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($modul->modul_id); ?>"><?php echo e($modul->modul_desc); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">SubModul ID</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="submodul_id" id="submodul_id" value="<?php if(isset($sub->submodul_id)): ?><?php echo e($sub->submodul_id); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">SubModul Description</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="submodul_desc" id="submodul_desc" value="<?php if(isset($sub->submodul_desc)): ?><?php echo e($sub->submodul_desc); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">SubModul Page</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="submodul_page" id="submodul_page" value="<?php if(isset($sub->submodul_page)): ?><?php echo e($sub->submodul_page); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\rwh\resources\views/submodul/form.blade.php */ ?>