<?php
    use App\BankMember;
?>
<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Index Member</h4>
                <p class="text-muted font-14 m-b-30">
                    <a href="<?php echo e(route('member.create')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Member</a>
                </p>
                <table class="table table-bordered" id="users-table">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Created At</th>
                            <th>Updated At</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<script type="text/javascript">

$(function() {
    $('#users-table').DataTable({
        processing: true,
        serverSide: true,
        deferRender: true,
        ajax: 'user/json',
        columns: [
            { data: 'id', name: 'id' },
            { data: 'name', name: 'name' },
            { data: 'email', name: 'email' },
            { data: 'created_at', name: 'created_at' },
            { data: 'updated_at', name: 'updated_at' }
        ]
    });
    // $('#users-table').DataTable({
	// 	"processing":true,
	// 	"serverSide":true,
	// 	"order":[],
	// 	"ajax":{
	// 		url:"user/json",
	// 		type:"POST"
	// 	},
	// 	"columnDefs":[
	// 		{
	// 			"target":[0,3,4],
	// 			"orderable":false
	// 		}
	// 	]
	// });
    // $('#example').DataTable( {
    //     serverSide: true,
    //     ordering: false,
    //     searching: false,
    //     ajax: function ( data, callback, settings ) {
    //         var out = [];
 
    //         for ( var i=data.start, ien=data.start+data.length ; i<ien ; i++ ) {
    //             out.push( [ i+'-1', i+'-2', i+'-3', i+'-4', i+'-5' ] );
    //         }
 
    //         setTimeout( function () {
    //             callback( {
    //                 draw: data.draw,
    //                 data: out,
    //                 recordsTotal: 5000000,
    //                 recordsFiltered: 5000000
    //             } );
    //         }, 50 );
    //     },
    //     scrollY: 200,
    //     scroller: {
    //         loadingIndicator: true
    //     },
    // });
});
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/member/index2.blade.php */ ?>