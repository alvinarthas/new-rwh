<?php
    use App\SubModul;
    use App\MenuMapping;
?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="<?php echo e(route('deleteMapping')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">Current Mapping</h4>

                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            
                            <th>Nama Modul</th>
                            <th>Nama Submodul</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $currents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                
                                <td><?php echo e($current->modul_desc); ?></td>
                                <td><?php echo e($current->submodul_desc); ?></td>
                                <td>
                                    <?php $__currentLoopData = $current->submapping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="checkbox checkbox-primary">
                                        <input id="checkboxcurrent<?php echo e($submap->submapping_id); ?>" name="current[]" type="checkbox" value="<?php echo e($submap->submapping_id); ?>">
                                            <label for="checkboxcurrent<?php echo e($submap->submapping_id); ?>">
                                                <?php echo e($submap->jenis_id); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>

    
    <form action="<?php echo e(route('storeMapping')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">List Modul</h4>

                    <table id="responsive-datatable2" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Modul</th>
                            <th>Nama Submodul</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $rests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($i); ?>

                                </td>
                                <td><?php echo e($rest->modul); ?></td>
                                <td><?php echo e($rest->submodul); ?></td>
                                <td>
                                    <?php $__currentLoopData = $rest->submapping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="checkbox checkbox-primary">
                                            <input id="checkboxrest<?php echo e($submap->id); ?>" name="rest[]" type="checkbox" value="<?php echo e($submap->id); ?>">
                                            <label for="checkboxrest<?php echo e($submap->id); ?>">
                                                <?php echo e($submap->jenis_id); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/menumapping/form.blade.php ENDPATH**/ ?>