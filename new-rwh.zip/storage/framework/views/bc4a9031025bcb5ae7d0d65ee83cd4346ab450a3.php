<div id="load" class="table-responsive">
    <table class="table m-b-0">
        <thead>
            <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Created_at</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data1['no']); ?></td>
                <td><?php echo e($data1['ktp']); ?></td>
                <td><?php echo e($data1['nama']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
    <?php echo e($data2); ?> 
</div>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/test/list.blade.php */ ?>