<div class="card-box">
    <div class="row">
        <div class="form-row">
            <div class="form-group col-md-4">
                <label for="salesid" class="col-form-label">Delivery ID</label>
                <input type="text" class="form-control" id="salesid" value="DO.<?php echo e($do->id); ?>" readonly>
            </div>
            <div class="form-group col-md-4">
                <label for="salesdate" class="col-form-label">Delivery Date</label>
                <input type="text" class="form-control" id="salesdate" value="<?php echo e($do->date); ?>" readonly>
            </div>
            <div class="form-group col-md-4">
                <label for="salesdate" class="col-form-label">Creator</label>
                <input type="text" class="form-control" id="salesdate" value="<?php echo e($do->petugas()->first()->name); ?>" readonly>
            </div>
        </div>
        <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Qty</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dodets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dodet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dodet->product_id); ?></td>
                        <td><?php echo e($dodet->product->name); ?></td>
                        <td><?php echo e($dodet->qty); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/sales/do/modal.blade.php ENDPATH**/ ?>