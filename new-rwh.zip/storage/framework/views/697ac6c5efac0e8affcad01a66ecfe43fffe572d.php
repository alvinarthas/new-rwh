<?php
    use App\ManageHarga;
?>
<form action="<?php echo e(route('manageharga.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="month" id="month" value="<?php echo e($month); ?>"/>
    <input type="hidden" name="year" id="year" value="<?php echo e($year); ?>"/>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Index Product</h4>

                <table id="responsive-datatable" class="table table-bordered dt-responsive wrap" cellspacing="0">
                    <thead>
                        <th style="width:10%">No</th>
                        <th style="width:5%">Product ID</th>
                        
                        <th width="5%">Product Name</th>
                        <th style="width:10%">Product Brand</th>
                        <th style="width:10%">Posting Bulan Ini</th>
                        <th style="width:7%">Harga Distributor</th>
                        <th style="width:7%">Harga Modal</th>
                        <th style="width:10%">Selisih</th>
                        <th style="width:10%">Bonus</th>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                                $i++;
                            ?>
                            <td><?php echo e($i); ?></td>
                            <input type="hidden" name="i" id="i" value="<?php echo e($i); ?>"/>
                            <td><?php echo e($prd->prod_id); ?></td>
                            <input type="hidden" name="pid[]" id="pid<?php echo e($i); ?>" value="<?php echo e($prd->prod_id); ?>"/>
                            
                            <td><?php echo e($prd->name); ?></td>
                            <td><?php echo e($prd->category); ?></td>
                            <td>
                                <?php
                                    $postingan = DB::table('tblpotrxdet')->where('prod_id', $prd->prod_id)->join('tblpotrx','tblpotrxdet.trx_id','=','tblpotrx.id')->where('tblpotrx.month',$month)->where('tblpotrx.year',$year)->sum('tblpotrxdet.qty');
                                ?>
                                <?php echo e($postingan); ?>

                            </td>
                                <?php
                                    $data1 = ManageHarga::where('prod_id', $prd->prod_id)->where('month', $month)->where('year', $year)->select('harga_distributor','harga_modal')->first();
                                    if($data1['harga_distributor']==0){
                                        if($month==1){
                                            $data1 = ManageHarga::where('prod_id', $prd->prod_id)->where('year', $year-1)->where('month', 12)->select('harga_distributor', 'harga_modal')->first();
                                        }
                                        else{
                                            $data1 = ManageHarga::where('prod_id', $prd->prod_id)->where('year', $year)->where('month', $month-1)->select('harga_distributor','harga_modal')->first();
                                        }
                                    }

                                    if(($data1['harga_distributor'] AND $data1['harga_modal']) == ""){
                                        $harga_dist = 0;
                                        $harga_mod = 0;
                                    }else{
                                        $harga_dist = $data1['harga_distributor'];
                                        $harga_mod = $data1['harga_modal'];
                                    }

                                ?>
                            <td>
                                <input name="price_dis[]" type="text" id="price_dis<?php echo e($i); ?>" value="<?php echo e($harga_dist); ?>" size="15" maxlength="15"/>
                            </td>
                            <td>
                                <input name="price_mod[]" type="text" id="price_mod<?php echo e($i); ?>" value="<?php echo e($harga_mod); ?>" size="15" maxlength="15"/>
                            </td>
                            <td>
                                <?php ($selisih = $harga_dist - $harga_mod); ?>
                                <?php echo e($selisih); ?>

                            </td>
                            <td>
                                <?php ($bonus=$postingan*$selisih); ?>
                                <?php echo e($bonus); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="form-group text-right m-b-0">
                    <button class="btn btn-primary waves-effect waves-light">
                        Update Harga
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>
    <script type="text/javascript">
        $(document).ready(function () {
            // Responsive Datatable
            $('#responsive-datatable').DataTable({
                paging : false,
                scrollY: 400
            });
        });
        function btnSave(){
            var mo = $('#month').val();
            var ye = $('#year').val();
            console.log(ye)

        }
    </script>
<?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/product/showProdAjxLog.blade.php ENDPATH**/ ?>