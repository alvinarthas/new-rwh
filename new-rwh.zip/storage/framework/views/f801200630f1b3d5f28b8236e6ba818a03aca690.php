<?php
    use App\DataKota;
?>
<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- form Uploads -->
    <link href="<?php echo e(asset('assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('member.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('member.update',['id' => $member->id])); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>

    <?php echo csrf_field(); ?>
    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Informasi Pribadi</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nama Lengkap</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="nama" id="nama" value="<?php if(isset($member->nama)): ?><?php echo e($member->nama); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nomor KTP</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="ktp" id="ktp" value="<?php if(isset($member->ktp)): ?><?php echo e($member->ktp); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nama Ibu Kandung</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="ibu" id="ibu" value="<?php if(isset($member->ibu)): ?><?php echo e($member->ibu); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Alamat</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="alamat" id="alamat" value="<?php if(isset($member->alamat)): ?><?php echo e($member->alamat); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Telepon</label>
                                <div class="col-10">
                                    <input type="number" class="form-control" parsley-trigger="change" required name="telp" id="telp" value="<?php if(isset($member->telp)): ?><?php echo e($member->telp); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Tempat Lahir</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="tempat_lahir" parsley-trigger="change" required id="tempat_lahir" value="<?php if(isset($member->tempat_lahir)): ?><?php echo e($member->tempat_lahir); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Tanggal Lahir</label>
                                <div class="col-10">
                                    <div class="input-group">
                                        <input type="text" class="form-control" parsley-trigger="change" required placeholder="yyyy/mm/dd" name="tanggal_lahir" id="tanggal_lahir"  value="<?php if(isset($member->tanggal_lahir)): ?><?php echo e($member->tanggal_lahir); ?><?php endif; ?>"  data-date-format='yyyy-mm-dd'>
                                        <div class="input-group-append">
                                            <span class="input-group-text"><i class="ti-calendar"></i></span>
                                        </div>
                                    </div><!-- input-group -->
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Provinsi</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="prov" id="prov" onchange="getKota(this.value)">
                                        <option value="#" disabled selected>Pilih Provinsi</option>
                                        <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($member->prov)): ?>
                                                <?php if($prov->kode_pusdatin_prov == $member->prov): ?>
                                                    <option value="<?php echo e($prov->kode_pusdatin_prov); ?>" selected><?php echo e($prov->provinsi); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($prov->kode_pusdatin_prov); ?>"><?php echo e($prov->provinsi); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($prov->kode_pusdatin_prov); ?>"><?php echo e($prov->provinsi); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Kab/Kota</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="city" id="city">
                                        <option value="#" disabled selected>Pilih Kab/Kota</option>
                                            <?php if(isset($member->city)): ?>
                                                <?php ($city = DataKota::getCity($member->city)); ?>
                                                <option value="<?php echo e($prov->kode_pusdatin_kota); ?>"><?php echo e($modul->kab_kota); ?></option>
                                            <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Koordinator</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="koordinator" id="koordinator">
                                        <option value="#" disabled selected>Pilih Koordinator</option>
                                        <?php $__currentLoopData = $koordinator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $koor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($member->koor)): ?>
                                                <?php if($koor->id == $member->koordinator): ?>
                                                    <option value="<?php echo e($koor->id); ?>" selected><?php echo e($koor->nama); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($koor->id); ?>"><?php echo e($koor->nama); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($koor->id); ?>"><?php echo e($koor->nama); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Sub Koordinator</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="koordinator" id="koordinator">
                                        <option value="#" disabled selected>Pilih Sub Koordinator</option>
                                        <?php $__currentLoopData = $subkoor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($member->subkoor)): ?>
                                                <?php if($sub->id == $member->subkoor): ?>
                                                    <option value="<?php echo e($sub->id); ?>" selected><?php echo e($sub->nama); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->nama); ?></option>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <option value="<?php echo e($sub->id); ?>"><?php echo e($sub->nama); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Upload Foto KTP</label>
                                <div class="col-10">
                                    <input type="file" class="dropify" data-height="100" name="scanktp" id="scanktp" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Plugin -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- file uploads js -->
<script src="<?php echo e(asset('assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });
    </script>

    <script>
        function getKota(id){
            $.ajax({
                url : "<?php echo e(route('getDataKota')); ?>",
                type : "get",
                dataType: 'html',
                data:{
                    prov: id,
                },
            }).done(function (data) {
                $('#city').html(data);
            }).fail(function (msg) {
                alert('Gagal menampilkan data, silahkan refresh halaman.');
            });
        }
        // Date Picker
        jQuery('#tanggal_lahir').datepicker();
        jQuery('#mulai_kerja').datepicker();

        // Select2
        $(".select2").select2({
        });
    </script>

    <script type="text/javascript">
        $('.dropify').dropify({
            messages: {
                'default': 'Drag and drop a file here or click',
                'replace': 'Drag and drop or click to replace',
                'remove': 'Remove',
                'error': 'Ooops, something wrong appended.'
            },
            error: {
                'fileSize': 'The file size is too big (1M max).'
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/member/form.blade.php */ ?>