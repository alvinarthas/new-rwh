<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                    <th>Transaction ID</th>
                    <th>Supplier</th>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Qty</th>
                    <th>Unit</th>
                    <th>Qty Receive</th>
                </thead>
                <tbody>
                    <?php echo csrf_field(); ?>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('receiveProdDet',['trx_id'=>$list->trx_id])); ?>" class="btn btn-primary btn-trans waves-effect w-xs waves-danger m-b-5 ">PO.<?php echo e($list->trx_id); ?></a></td>
                            <td><?php echo e($list->supplier); ?></td>
                            <td><?php echo e($list->prod_id); ?></td>
                            <td><?php echo e($list->prod_name); ?></td>
                            <td><?php echo e($list->qty); ?></td>
                            <td><?php echo e($list->unit); ?></td>
                            <?php if($list->qtyrec == 0): ?>
                                <td><a href="javascrip:;" class="btn btn-danger btn-rounded waves-effect w-xs waves-danger m-b-5 disabled"><?php echo e($list->qtyrec); ?></a></td>
                            <?php elseif(($list->qtyrec-$list->qty) == 0 ): ?>
                                <td><a href="javascrip:;" class="btn btn-success btn-rounded waves-effect w-xs waves-danger m-b-5 disabled"><?php echo e($list->qtyrec); ?></a></td>
                            <?php elseif(($list->qtyrec-$list->qty) < 0 ): ?>
                                <td><a href="javascrip:;" class="btn btn-warning btn-rounded waves-effect w-xs waves-danger m-b-5 disabled"><?php echo e($list->qtyrec); ?></a></td>
                            <?php else: ?>
                                <td><a href="javascrip:;" class="btn btn-info btn-rounded waves-effect w-xs waves-danger m-b-5 disabled"><?php echo e($list->qtyrec); ?></a></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Responsive Datatable
$('#responsive-datatable').DataTable();

function deletePurchase(id){
    var token = $("meta[name='csrf-token']").attr("content");

    swal({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        confirmButtonClass: 'btn btn-success',
        cancelButtonClass: 'btn btn-danger m-l-10',
        buttonsStyling: false
    }).then(function () {
        $.ajax({
            url: "purchase/"+id,
            type: 'DELETE',
            data: {
                "id": id,
                "_token": token,
            },
        }).done(function (data) {
            swal(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
            location.reload();
        }).fail(function (msg) {
            swal(
                'Failed',
                'Your imaginary file is safe :)',
                'error'
            )
        });
        
    }, function (dismiss) {
        // dismiss can be 'cancel', 'overlay',
        // 'close', and 'timer'
        if (dismiss === 'cancel') {
            console.log("eh ga kehapus");
            swal(
                'Cancelled',
                'Your imaginary file is safe :)',
                'error'
            )
        }
    })
}
</script>
<?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/purchase/receive/indexreceive.blade.php ENDPATH**/ ?>