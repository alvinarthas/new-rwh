<div class="row">
    <div class="col-12">
        <div class="card-box table-responsive">
            <h4 class="m-t-0 header-title">Laporan Neraca</h4>
            
            <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                    <th colspan="2" style="text-align:center;background:dodgerblue">Aktiva</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $dataaktiva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="font-weight: bold">
                            <td><?php echo e($item['grup']['AccNo']); ?> - <?php echo e($item['grup']['AccName']); ?></td>
                            <td style="text-align:right">Rp. <?php echo e(number_format($item['sum'])); ?></td>
                        </tr>

                        <?php $__currentLoopData = $item['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>&ensp;&ensp;<?php echo e($item2['data']['AccNo']); ?> - <?php echo e($item2['data']['AccName']); ?></td>
                                <td style="text-align:right">Rp. <?php echo e(number_format($item2['total'])); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <td colspan="2" style="text-align:center;font-weight: bold">Total Aktiva: Rp. <?php echo e(number_format($sum_aktiva)); ?></td>
                </tfoot>
            </table>
            <br><br><br>
            <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                    <th colspan="2" style="text-align:center;background:dodgerblue">Pasiva</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datapasiva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="font-weight: bold">
                            <td><?php echo e($itemp['grup']['AccNo']); ?> - <?php echo e($itemp['grup']['AccName']); ?></td>
                            <td style="text-align:right">Rp. <?php echo e(number_format($itemp['sum'])); ?></td>
                        </tr>

                        <?php $__currentLoopData = $itemp['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemp2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>&ensp;&ensp;<?php echo e($itemp2['data']['AccNo']); ?> - <?php echo e($itemp2['data']['AccName']); ?></td>
                                <td style="text-align:right">Rp. <?php echo e(number_format($itemp2['total'])); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <td colspan="2" style="text-align:center;font-weight: bold">Total Aktiva: Rp. <?php echo e(number_format($sum_pasiva)); ?></td>
                </tfoot>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/laporan/balance_sheet/view_laporan_neraca.blade.php ENDPATH**/ ?>