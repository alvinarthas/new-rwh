<?php
    use App\SubModul;
    use App\MenuMapping;
?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="<?php echo e(route('PurMapDelete')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">Current Mapping</h4>

                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Perusahaan</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $currents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($current->supplier->nama); ?></td>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <input id="checkboxcurrent<?php echo e($current->supplier_id); ?>" name="current[]" type="checkbox" value="<?php echo e($current->supplier_id); ?>">
                                        <label for="checkboxcurrent<?php echo e($current->supplier_id); ?>"></label>
                                    </div>
                                </td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>

    
    <form action="<?php echo e(route('PurMapStore')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">List Supplier</h4>

                    <table id="responsive-datatable2" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Supplier</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            <?php ($i = 1); ?>
                            <?php $__currentLoopData = $rests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($i); ?>

                                </td>
                                <td><?php echo e($rest->nama); ?></td>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <input id="checkboxrest<?php echo e($rest->id); ?>" name="rest[]" type="checkbox" value="<?php echo e($rest->id); ?>">
                                        <label for="checkboxrest<?php echo e($rest->id); ?>">
                                        </label>
                                    </div>
                                </td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/purchase/map/form.blade.php ENDPATH**/ ?>