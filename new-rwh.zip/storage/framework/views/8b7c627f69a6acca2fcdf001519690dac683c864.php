<?php
    use App\SubModul;
    use App\JenisMapping;
?>
<?php $__env->startSection('css'); ?>
    
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <form action="<?php echo e(route('updateRoleMapping',['id'=>$id])); ?>" method="post">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">Role Mapping: <?php echo e($id); ?></h4>

                    <div class="p-20">
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Role</label>
                            <div class="col-10">
                                <select class="form-control select2" parsley-trigger="change" name="role_id">
                                    <option value="#" disabled selected>Pilih Role</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($user->role_id)): ?>
                                            <?php if($user->role_id == $role->id): ?>
                                                <option value="<?php echo e($role->id); ?>" selected><?php echo e($role->role_name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($role->id); ?>" ><?php echo e($role->role_name); ?></option>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <option value="<?php echo e($role->id); ?>" ><?php echo e($role->role_name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/rolemapping/form.blade.php */ ?>