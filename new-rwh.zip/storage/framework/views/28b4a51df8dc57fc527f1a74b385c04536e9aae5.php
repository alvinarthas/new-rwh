<?php
    use App\ManageHarga;
?>
<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- Sweet Alert css -->
    <link href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <link href="<?php echo e(asset('assets/fingerprint/ajaxmask.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Form Update Purchasing
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Supplier Data</h4>
                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                <thead>
                                    <th>No</th>
                                    <th>Supplier Name</th>
                                    <th>Company Address</th>
                                    <th>Company Phone</th>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><?php echo e($purchase->supplier()->first()->nama); ?></td>
                                        <td><?php echo e($purchase->supplier()->first()->alamat); ?></td>
                                        <td><?php echo e($purchase->supplier()->first()->telp); ?></td>
                                    </tr>
                                </tbody>
                            </table>
            
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Posting Period</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" value="<?php echo e(date("F", mktime(0, 0, 0, $purchase->month, 10))); ?> <?php echo e($purchase->year); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card-box">
                <h4 class="m-t-0 header-title">Insert Item</h4>
                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Choose Product Name</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="select_product" id="select_product">
                                        <option value="#" selected>Pilih Product</option>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($product->prod_id); ?>"><?php echo e($product->prod_id); ?> - <?php echo e($product->name); ?> - Rp.<?php echo e(number_format($product->harga_distributor)); ?> - Rp.<?php echo e(number_format($product->harga_modal)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Quantity</label>
                                <div class="col-10">
                                    <input type="number" class="form-control" name="qty" id="qty" parsley-trigger="change" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Unit</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" name="unit" id="unit" parsley-trigger="change" required>
                                </div>
                            </div>
                            <div class="form-group text-right m-b-0">
                                <a href="javascript:;" class="btn btn-danger btn-rounded w-md waves-effect waves-light m-b-5" onclick="addItem()">Tambah Item</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <form class="form-horizontal" role="form" action="<?php echo e(route('purchase.update',['id'=>$purchase->id])); ?>" enctype="multipart/form-data" method="POST">
                <?php echo e(method_field('PUT')); ?>

                <?php echo csrf_field(); ?>
                
                <input type="hidden" name="bulanpost" id="bulanpost" value="<?php echo e($purchase->month); ?>">
                <input type="hidden" name="tahunpost" id="tahunpost" value="<?php echo e($purchase->year); ?>">
                <input type="hidden" name="supplierpost" id="supplierpost" value="<?php echo e($purchase->supplier); ?>">
                <div class="card-box">
                    <div class="row">
                        <h4 class="m-t-0 header-title">Purchase Order Item Details</h4>
                        <div class="col-12">
                            <div class="p-20">
                                <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <thead>
                                        <th>No</th>
                                        <th>Product ID</th>
                                        <th>Product Name</th>
                                        <th>Qty</th>
                                        <th>Unit</th>
                                        <th>Harga Distributor</th>
                                        <th>Harga Modal</th>
                                        <th>Sub Total Distributor</th>
                                        <th>Sub Total Modal</th>
                                        <th>Option</th>
                                    </thead>
                                    <tbody id="purchase-list-body">
                                        <?php ($i=1); ?>
                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr style="width:100%" id="trow<?php echo e($i); ?>">
                                                <td><?php echo e($i); ?></td>
                                                <td><?php echo e($detail->prod_id); ?></td>
                                                <td><?php echo e($detail->product->name); ?></td>
                                                <td><?php echo e($detail->qty); ?></td>
                                                <td><?php echo e($detail->unit); ?></td>
                                                <td>Rp. <?php echo e(number_format($detail->price_dist)); ?></td>
                                                <td>Rp. <?php echo e(number_format($detail->price)); ?></td>
                                                <td><input type="hidden" value="<?php echo e($detail->price_dist*$detail->qty); ?>" id="sub_ttl_dist<?php echo e($i); ?>">Rp. <?php echo e(number_format($detail->price_dist*$detail->qty)); ?></td>
                                                <td><input type="hidden" value="<?php echo e($detail->price*$detail->qty); ?>" id="sub_ttl_mod<?php echo e($i); ?>">Rp. <?php echo e(number_format($detail->price*$detail->qty)); ?></td>
                                                <td><a href="javascript:;" type="button" class="btn btn-danger btn-trans waves-effect w-md waves-danger m-b-5" onclick="deleteItem(<?php echo e($i); ?>,<?php echo e($detail->id); ?>)">Delete</a></td>
                                            </tr>
                                        <?php ($i++); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" name="count" id="count" value="<?php echo e($i-1); ?>">
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <h4 class="m-t-0 header-title">Purchase Order Date and Notes</h4>
                        <div class="col-12">
                            <div class="p-20">
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Total Harga Distributor</label>
                                    <div class="col-10">
                                        <input type="number" class="form-control" name="ttl_harga_distributor" id="ttl_harga_distributor" parsley-trigger="change" value="<?php echo e($ttl_harga_dist); ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Total Harga Modal</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="ttl_harga_modal" id="ttl_harga_modal" parsley-trigger="change" value="<?php echo e($ttl_harga_modal); ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">PO Date</label>
                                    <div class="col-10">
                                        <div class="input-group">
                                            <input type="text" class="form-control" parsley-trigger="change" required placeholder="yyyy/mm/dd" name="po_date" id="po_date" value="<?php echo e($purchase->tgl); ?>"  data-date-format='yyyy-mm-dd' autocomplete="off">
                                            <div class="input-group-append">
                                                <span class="input-group-text"><i class="ti-calendar"></i></span>
                                            </div>
                                        </div><!-- input-group -->
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Notes</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="notes" id="notes" parsley-trigger="change">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group text-right m-b-0">
                        <?php if($purchase->approve == 0): ?>
                        <?php
                            $url_register		= base64_encode(route('purchaseApprove',['user_id'=>session('user_id'),'trx_id'=>$purchase->id]));
                        ?>
                            <a href="finspot:FingerspotVer;<?=$url_register?>" class="btn btn-success btn-trans waves-effect w-md waves-danger m-b-5">Approve Purchase</a>
                        <?php else: ?>
                            <a class="btn btn-inverse btn-trans waves-effect w-md waves-danger m-b-5">Purchase sudah di approve</a>
                        <?php endif; ?>
                        <button class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Simpan Purchase Order</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
    
    <script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- Sweet Alert Js  -->
    <script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/pages/jquery.sweet-alert.init.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/fingerprint/jquery.timer.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/fingerprint/ajaxmask.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<script>
// Select2
$(".select2").select2();

// Date Picker
jQuery('#po_date').datepicker();

function addItem(){
    bulanpost = $('#bulanpost').val();
    tahunpost = $('#tahunpost').val();
    select_product = $('#select_product').val();
    qty = $('#qty').val();
    unit = $('#unit').val();
    count = $('#count').val();

    $.ajax({
        url : "<?php echo e(route('addPurchase')); ?>",
        type : "get",
        dataType: 'json',
        data:{
            select_product: select_product,
            bulan: bulanpost,
            tahun: tahunpost,
            qty: qty,
            unit: unit,
            count:count,
        },
    }).done(function (data) {
        $('#purchase-list-body').append(data.append);
        $('#count').val(data.count);
        resetall();
        changeTotalHarga(data.sub_ttl_mod, data.sub_ttl_dist);
    }).fail(function (msg) {
        alert('Gagal menampilkan data, silahkan refresh halaman.');
    });
}

function changeTotalHarga(sub_ttl_mod,sub_ttl_dist){
    ttl_harga_distributor = parseInt($('#ttl_harga_distributor').val());
    ttl_harga_modal = parseInt($('#ttl_harga_modal').val());
    new_total_dist = ttl_harga_distributor+sub_ttl_dist;
    new_total_modal = ttl_harga_modal+sub_ttl_mod;
    $('#ttl_harga_distributor').val(new_total_dist);
    $('#ttl_harga_modal').val(new_total_modal);
}

function decreaseTotalHarga(id){
    ttl_harga_distributor = parseInt($('#ttl_harga_distributor').val());
    ttl_harga_modal = parseInt($('#ttl_harga_modal').val());
    sub_ttl_dist = $('#sub_ttl_dist'+id).val();
    sub_ttl_mod = $('#sub_ttl_mod'+id).val();
    new_total_dist = ttl_harga_distributor-sub_ttl_dist;
    new_total_modal = ttl_harga_modal-sub_ttl_mod;
    $('#ttl_harga_distributor').val(new_total_dist);
    $('#ttl_harga_modal').val(new_total_modal);
}

function resetall(){
    $('#select_product').val("#").change();
    $('#qty').val("");
    $('#unit').val("");
}

function deleteItem(id,purdet){
    swal({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        confirmButtonClass: 'btn btn-success',
        cancelButtonClass: 'btn btn-danger m-l-10',
        buttonsStyling: false
    }).then(function () {
        $.ajax({
            url : "<?php echo e(route('destroyPurchaseDetail')); ?>",
            type : "get",
            dataType: 'json',
            data:{
                detail: purdet,
            },
        }).done(function (data) {
            swal(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
            count = parseInt($('#count').val()) - 1;
            decreaseTotalHarga(id);
            $('#trow'+id).remove();
            $('#count').val(count);
        }).fail(function (msg) {
            swal(
                'Failed',
                'Your imaginary file is safe :)',
                'error'
            )
        });
        
    }, function (dismiss) {
        // dismiss can be 'cancel', 'overlay',
        // 'close', and 'timer'
        if (dismiss === 'cancel') {
            console.log("eh ga kehapus");
            swal(
                'Cancelled',
                'Your imaginary file is safe :)',
                'error'
            )
        }
    })
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/purchase/form_update.blade.php */ ?>