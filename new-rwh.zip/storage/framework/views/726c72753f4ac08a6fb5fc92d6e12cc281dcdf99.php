<?php
    use App\Modul;
    use App\SubModul;
?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    use Carbon\Carbon;
?>
<div class="bg-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="home-fullscreen">
                    <div class="full-screen">
                        <div class="home-wrapper home-wrapper-alt">
                            <div class="row">
                                <div class="form-group col-md-2">
                                    <img src="<?php echo e(asset('assets/images/employee/foto/'.session('foto'))); ?>"  alt="user-img" title="<?php echo e(session('name')); ?>" class="rounded-circle img-thumbnail img-responsive photo">
                                </div>
                                <div class="form-group col-md-8">
                                    <h1 class="text-dark">Hai <?php echo e(session('name')); ?>,</h1>
                                    <?php
                                        Carbon::setLocale('id');
                                        $getTime = Carbon::now()->setTimezone('Asia/Phnom_Penh')->toTimeString();
                                        if(($getTime>'11:00:00') && ($getTime<='15:00:00')){
                                            $time = "SIANG";
                                        }elseif(($getTime>'15:00:00') && ($getTime<='18:00:00')){
                                            $time = "SORE";
                                        }elseif(($getTime>'18:00:00') && ($getTime<='00:00:00')){
                                            $time = "MALAM";
                                        }else{
                                            $time = "PAGI";
                                        }
                                    ?>
                                    <p class="text-dark">SELAMAT <?php echo e($time); ?>, DAN SELAMAT BEKERJA!</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/welcome/welcome.blade.php ENDPATH**/ ?>