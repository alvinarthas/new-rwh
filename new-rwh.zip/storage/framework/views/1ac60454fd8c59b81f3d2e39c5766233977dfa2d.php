<?php
    use App\Coa;
?>


<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- form Uploads -->
    <link href="<?php echo e(asset('assets/plugins/fileuploads/css/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Tambah Data Coa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($jenis == "create"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('coa.store')); ?>" enctype="multipart/form-data" method="POST">
    <?php elseif($jenis == "edit"): ?>
        <form class="form-horizontal" role="form" action="<?php echo e(route('coa.update', ['id' => $coa->id])); ?>" enctype="multipart/form-data" method="POST">
            <?php echo e(method_field('PUT')); ?>

    <?php endif; ?>

    <?php echo csrf_field(); ?>

    
    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">Data Coa</h4>
                <p class="text-muted m-b-30 font-14">
                </p>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Account Number</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="account_number" id="account_number" value="<?php if(isset($coa->AccNo)): ?><?php echo e($coa->AccNo); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Account Name</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="account_name" id="account_name" value="<?php if(isset($coa->AccName)): ?><?php echo e($coa->AccName); ?><?php endif; ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Posisi Saldo Normal</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="saldo_normal">
                                        <option value="Db">Debet</option>
                                        <option value="Cr">Kredit</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Status Account</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="status_account">
                                        <option value="Grup">Grup</option>
                                        <option value="Detail">Detail</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Account Parent</label>
                                <div class="col-10">
                                    <select class="form-control select2" parsley-trigger="change" name="account_parent" id="account_parent">
                                        <?php if(isset($coa->AccParent)): ?>
                                            <option value="<?php echo e($coa->AccParent); ?>" selected><?php echo e($coa->AccParent); ?> -  <?php echo e(Coa::where('AccNo',$coa->AccParent)->select('AccName')->first()->AccName); ?></option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Nominal Saldo Awal</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" parsley-trigger="change" required name="saldo_awal" id="saldo_awal" value="<?php if(isset($coa->SaldoAwal)): ?><?php echo e($coa->SaldoAwal); ?><?php endif; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group text-right m-b-0">
        <button class="btn btn-primary waves-effect waves-light" type="submit">
            Submit
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Plugin -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- file uploads js -->
<script src="<?php echo e(asset('assets/plugins/fileuploads/js/dropify.min.js')); ?>"></script>
<!-- Validation js (Parsleyjs) -->
<script type="text/javascript" src="<?php echo e(asset('assets/plugins/parsleyjs/dist/parsley.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('form').parsley();
        });
    </script>

    <script>
        // Date Picker
        jQuery('#tanggal_lahir').datepicker();
        jQuery('#mulai_kerja').datepicker();

        // Select2
        $(".select2").select2();

        $("#account_parent").select2({
            placeholder:"Pilih Coa Parent",
            ajax:{
                url: "<?php echo e(route('ajxCoa')); ?>",
                dataType:'json',    
                delay:250,
                data:function(params){
                    return{
                        params:params.term,
                    };
                },
                processResults:function(data){
                    var item = $.map(data, (value)=>{ //map buat ngemap object data kyk foreach
                        return { id: value.id, text: value.text };
                    });

                    return {
                        results: item
                    }
                },
                cache: true
            },
            minimumInputLength: 1,
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/coa/form.blade.php ENDPATH**/ ?>