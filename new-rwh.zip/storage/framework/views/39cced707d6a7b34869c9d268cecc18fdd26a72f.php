<div class="col-12">
    <div class="card-box table-responsive">
        <h4 class="m-t-0 header-title">Log Kehadiran: <?php echo e($tanggal_awal); ?> s/d <?php echo e($tanggal_akhir); ?></h4>
        <p class="text-muted m-b-30 font-14">
        </p>

        <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
            <thead>
                <th>No</th>
                <th>Username</th>
                <th>Log Kehadiran</th>
                <th>Data</th>
                <th>Keterangan</th>
            </thead>
            <tbody>
                <?php ($i=1); ?>
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($log->user_name); ?></td>
                        <td><?php echo e($log->log_time); ?></td>
                        <td><?php echo e($log->data); ?></td>
                        <td><?php echo e($log->keterangan); ?></td>
                    </tr>
                    <?php ($i++); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /* C:\xampp\htdocs\new-rwh\resources\views/absensi/ajxFullLog.blade.php */ ?>