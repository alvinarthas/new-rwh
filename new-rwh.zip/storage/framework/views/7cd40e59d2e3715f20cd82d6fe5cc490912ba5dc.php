<?php
    use App\Employee;
?>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!--venobox lightbox-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/magnific-popup/dist/magnific-popup.css')); ?>"/>
    <style>
    img.photo{
        display:block; width:50%; height:auto;
    }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card-box table-responsive">
                <h4 class="m-t-0 header-title">Index Employee</h4>
                <p class="text-muted font-14 m-b-30">
                    <a href="<?php echo e(route('createEmployee')); ?>" class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Tambah Pegawai</a>
                </p>

                <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                    <thead>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>NIP</th>
                        <th>Mulai Kerja</th>
                        <th>Alamat</th>
                        <th>No Hp</th>
                        <th>Action</th>
                        <th>Tempat Lahir</th>
                        <th>Tanggal Lahir</th>
                        <th>KTP</th>
                        <th>SIM A</th>
                        <th>SIM B</th>
                        <th>SIM C</th>
                        <th>NPWP</th>
                        <th>BPJS</th>
                    </thead>

                    <tbody>
                        <?php ($i = 1); ?>
                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/foto/'.$emp->scanfoto)); ?>" class="image-popup" title="<?php echo e($emp->name); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/foto/'.$emp->scanfoto)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td><?php echo e($emp->name); ?></td>
                            <td><?php echo e($emp->username); ?></td>
                            <td><?php echo e($emp->nip); ?></td>
                            <td><?php echo e($emp->start_work); ?></td>
                            <td><?php echo e($emp->address); ?></td>
                            <td><?php echo e($emp->phone); ?></td>
                            <td>
                                <a href="<?php echo e(route('editEmployee',['id'=>$emp->id])); ?>" class="btn btn-custom btn-rounded waves-effect waves-light w-md m-b-5">Edit</a>
                                <a href="" class="btn btn-danger btn-rounded waves-effect waves-light w-md m-b-5">Hapus</a>
                            </td>
                            <td><?php echo e($emp->tmpt_lhr); ?></td>
                            <td><?php echo e($emp->tgl_lhr); ?></td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/ktp/'.$emp->scanktp)); ?>" class="image-popup" title="KTP : <?php echo e($emp->ktp); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/ktp/'.$emp->scanktp)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/sima/'.$emp->scansima)); ?>" class="image-popup" title="SIM A: <?php echo e($emp->sima); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/sima/'.$emp->scansima)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/simb/'.$emp->scansimb)); ?>" class="image-popup" title="SIM B1: <?php echo e($emp->simb1); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/simb/'.$emp->scansimb)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/simc/'.$emp->scansimc)); ?>" class="image-popup" title="SIM C: <?php echo e($emp->simc); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/simc/'.$emp->scansimc)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/npwp/'.$emp->scannpwp)); ?>" class="image-popup" title="NPWP: <?php echo e($emp->npwp); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/npwp/'.$emp->scannpwp)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                            <td>
                                <a href="<?php echo e(asset('assets/images/employee/bpjs/'.$emp->scanbpjs)); ?>" class="image-popup" title="BPJS: <?php echo e($emp->bpjs); ?>">
                                    <img src="<?php echo e(asset('assets/images/employee/bpjs/'.$emp->scanbpjs)); ?>"  alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive photo">
                                </a>
                            </td>
                        </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Modal-Effect -->
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/custombox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/custombox/dist/legacy.min.js')); ?>"></script>

     <!-- Magnific popup -->
     <script type="text/javascript" src="<?php echo e(asset('assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<script type="text/javascript">

    $(document).ready(function () {

        // Responsive Datatable
        $('#responsive-datatable').DataTable();

        $('.image-popup').magnificPopup({
            type: 'image',
        });
    });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\rwh\resources\views/employee/index.blade.php */ ?>