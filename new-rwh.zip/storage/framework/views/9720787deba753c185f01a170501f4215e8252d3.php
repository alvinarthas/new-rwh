<!-- jQuery  -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/detect.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/fastclick.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.blockUI.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/waves.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.scrollTo.min.js')); ?>"></script>

<!-- Toastr js -->
<script src="<?php echo e(asset('assets/plugins/toastr/toastr.min.js')); ?>"></script>

<?php echo $__env->yieldContent('js'); ?>

<!-- App js -->
<script src="<?php echo e(asset('assets/js/jquery.core.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.app.js')); ?>"></script>

<?php if(session('status')): ?>
    <script>
        var status = "<?php echo e(session('status')); ?>";
        // Display a success toast, with a title
        toastr.success(status, 'Success')
    </script>
<?php elseif(session('warning')): ?>
    <script>
        var status = "<?php echo e(session('warning')); ?>";
        // Display a success toast, with a title
        toastr.warning(status, 'Warning!')
    </script>
<?php endif; ?>
<?php if($errors->any()): ?>
    <?php
        $er="";
    ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $er .= "<li>".$error."</li>";
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        var error = "<?=$er?>";
        // Display an error toast, with a title
        toastr.error(error, 'Error!!!')
    </script>
<?php endif; ?>
<?php echo $__env->yieldContent('script-js'); ?>
<?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/layout/js.blade.php ENDPATH**/ ?>