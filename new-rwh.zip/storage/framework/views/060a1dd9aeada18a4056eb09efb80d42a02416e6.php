<div class="card-box table-responsive">
    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <th>No</th>
            <th>Sales ID</th>
            <th>Customer</th>
            <th>Total Harga</th>
            <th>Status Delivery</th>
            <th>Option</th>
        </thead>
        <tbody>
            <?php ($i=1); ?>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td>SO.<?php echo e($sale['sales_id']); ?></td>
                    <td><?php echo e($sale['customer']); ?></td>
                    <td>Rp. <?php echo e(number_format($sale['ttl'])); ?></td>
                    <?php if($sale['status_do'] == 1): ?>
                        <td><a href="javascrip:;" class="btn btn-success btn-trans waves-effect w-md waves-danger m-b-5">Sudah selesai melakukan Delivery</a></td>
                    <?php else: ?>
                        <td><a href="javascrip:;" class="btn btn-danger btn-trans waves-effect w-md waves-danger m-b-5">Belum selesai melakukan Delivery</a></td>
                    <?php endif; ?>
                    <td><a href="<?php echo e(route('showDo',['id'=>$sale['sales_id']])); ?>" class="btn btn-primary btn-rounded waves-effect w-md waves-danger m-b-5">Atur</a></td>
                </tr>
            <?php ($i++); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/sales/do/view.blade.php ENDPATH**/ ?>