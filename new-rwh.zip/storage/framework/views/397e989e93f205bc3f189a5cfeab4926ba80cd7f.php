<?php $__env->startSection('css'); ?>
    
    <link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    <link href="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
    <!-- Sweet Alert css -->
    <link href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
Form Sales Payment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php if($jenis == "create"): ?>
                <form class="form-horizontal" role="form" action="<?php echo e(route('jurnal.store')); ?>" enctype="multipart/form-data" method="POST">
                <?php elseif($jenis == "edit"): ?>
                <form class="form-horizontal" role="form" action="<?php echo e(route('jurnal.update',['id' => $id])); ?>" enctype="multipart/form-data" method="POST">
                <?php echo e(method_field('PUT')); ?>

                <?php endif; ?>
                <?php echo csrf_field(); ?>
                    <div class="card-box">
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Pilih Chart of Account</label>
                            <div class="col-10">
                                <select class="form-control select2" parsley-trigger="change" name="coa" id="coa" required>
                                    <option value="#" disabled>Pilih Coa</option>
                                    <?php $__currentLoopData = $coas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($coa->AccNo); ?>"><?php echo e($coa->AccName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Position</label>
                            <div class="col-10">
                                <select class="form-control select2" parsley-trigger="change" name="position" id="position" required>
                                    <option value="Debet">Debet</option>
                                    <option value="Credit">Credit</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Amount</label>
                            <div class="col-10">
                                <input type="number" class="form-control" parsley-trigger="change" required name="amount" id="amount" value="0">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Catatan</label>
                            <div class="col-10">
                                <textarea class="form-control" rows="5" id="notes" name="notes"></textarea>
                            </div>
                        </div>
                        <div class="form-group text-right m-b-0">
                            <a href="javascript:;" class="btn btn-danger btn-rounded w-md waves-effect waves-light m-b-5" onclick="addAccount()">Add Account</a>
                        </div>
                    </div>
                    <div class="card-box">
                        <h4 class="m-t-0 header-title">Jurnal Entry Details</h4>
                        <div class="col-12">
                            <div class="p-20">
                                <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                                    <thead>
                                        <th>No</th>
                                        <th>Account Number</th>
                                        <th>Account Name</th>
                                        <th>Position</th>
                                        <th>Amount</th>
                                        <th>Notes</th>
                                        <th>Option</th>
                                    </thead>
                                    <tbody id="jurnal-list-body">
                                        <input type="hidden" name="count" id="count" value="<?php if(isset($count_edit)): ?><?php echo e($count_edit); ?><?php endif; ?>">
                                        <?php if($jenis == "edit"): ?>
                                            <?php ($i=1); ?>
                                            <?php $__currentLoopData = $jurnals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr style="width:100%" id="trow<?php echo e($i); ?>">
                                                    <td><?php echo e($i); ?></td>
                                                    <td><?php echo e($item->AccNo); ?></td>
                                                    <td><?php echo e($item->coa->AccName); ?></td>
                                                    <td><input type="hidden" value="<?php echo e($item->AccPos); ?>" id="position<?php echo e($i); ?>"><?php echo e($item->AccPos); ?></td>
                                                    <td><input type="hidden" value="<?php echo e($item->Amount); ?>" id="amount<?php echo e($i); ?>">Rp. <?php echo e(number_format($item->Amount)); ?></td>
                                                    <td><?php echo e($item->notes_item); ?></td>
                                                    <td><a href="javascript:;" type="button" class="btn btn-danger btn-trans waves-effect w-md waves-danger m-b-5" onclick="deleteItemJurnal(<?php echo e($i); ?>,<?php echo e($item->id); ?>)" >Delete</a></td>
                                                </tr>
                                            <?php ($i++); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card-box">
                        <?php if($jenis == "edit"): ?>
                            <div class="form-group row">
                                <label class="col-2 col-form-label">Jurnal ID</label>
                                <div class="col-10">
                                    <input type="text" class="form-control" value="<?php echo e($id); ?>" readonly>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Total Debet</label>
                            <div class="col-10">
                                <input type="number" class="form-control" name="ttl_debet" id="ttl_debet" parsley-trigger="change" value="<?php if(isset($ttl_debet)): ?><?php echo e($ttl_debet); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                                <label class="col-2 col-form-label">Total Credit</label>
                                <div class="col-10">
                                    <input type="number" class="form-control" name="ttl_credit" id="ttl_credit" parsley-trigger="change" value="<?php if(isset($ttl_credit)): ?><?php echo e($ttl_credit); ?><?php else: ?><?php echo e(0); ?><?php endif; ?>">
                                </div>
                            </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Transaction Date</label>
                            <div class="col-10">
                                <div class="input-group">
                                    <input type="text" class="form-control" parsley-trigger="change" required placeholder="yyyy/mm/dd" name="trx_date" id="trx_date"  data-date-format='yyyy-mm-dd' autocomplete="off" value="<?php if(isset($jurnals[0]->date)): ?><?php echo e($jurnals[0]->date); ?><?php endif; ?>">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="ti-calendar"></i></span>
                                    </div>
                                </div><!-- input-group -->
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-2 col-form-label">Description</label>
                            <div class="col-10">
                                <textarea class="form-control" rows="5" id="deskripsi" name="deskripsi"><?php if(isset($jurnals[0]->description)): ?><?php echo e($jurnals[0]->description); ?><?php endif; ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="form-group text-right m-b-0">
                        <button class="btn btn-success btn-rounded w-md waves-effect waves-light m-b-5">Simpan Jurnal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>" type="text/javascript"></script>


<script src="<?php echo e(asset('assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- Sweet Alert Js  -->
<script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/pages/jquery.sweet-alert.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<script>
    // Date Picker
    jQuery('#trx_date').datepicker({
        todayHighlight: true,
        autoclose: true
    });

    function addAccount(){
        coa = $('#coa').val();
        position = $('#position').val();
        amount = $('#amount').val();
        notes = $('#notes').val();
        count = $('#count').val();

        $.ajax({
            url : "<?php echo e(route('addJurnal')); ?>",
            type : "get",
            dataType: 'json',
            data:{
                coa: coa,
                position: position,
                amount: amount,
                notes: notes,
                count:count,
            },
        }).done(function (data) {
            $('#jurnal-list-body').append(data.append);
            $('#count').val(data.count);
            resetall();
            changeTotalHarga(data.ttl_debet,data.ttl_credit);
        }).fail(function (msg) {
            alert('Gagal menampilkan data, silahkan refresh halaman.');
        });
    }

    function resetall(){
        $('#coa').val("#").change();
        $('#position').val("Debet").change();
        $('#amount').val("0");
        $('#notes').val("");
    }

    function changeTotalHarga(ttl_debet_add,ttl_credit_add){
        ttl_debet = parseInt($('#ttl_debet').val());
        ttl_credit = parseInt($('#ttl_credit').val());
        $('#ttl_debet').val(ttl_debet+parseInt(ttl_debet_add))
        $('#ttl_credit').val(ttl_credit+parseInt(ttl_credit_add))
    }

    function deleteItem(id){
        count = parseInt($('#count').val()) - 1;
        decreaseTotalHarga(id);
        $('#trow'+id).remove();
        $('#count').val(count);
    }

    function decreaseTotalHarga(id){
        amount = parseInt($('#amount'+id).val());
        position = $('#position'+id).val();

        if(position == "Debet"){
            ttl_debet = parseInt($('#ttl_debet').val());
            $('#ttl_debet').val(ttl_debet-amount);
        }else{
            ttl_credit = parseInt($('#ttl_credit').val());
            $('#ttl_credit').val(ttl_credit-amount);
        }
    }

    function deleteItemJurnal(i,id){
        swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success',
            cancelButtonClass: 'btn btn-danger m-l-10',
            buttonsStyling: false
        }).then(function () {
            $.ajax({
                url : "<?php echo e(route('detailJuralDestroy')); ?>",
                type : "get",
                dataType: 'json',
                data:{
                    id: id,
                },
            }).done(function (data) {
                swal(
                    'Deleted!',
                    'Your file has been deleted.',
                    'success'
                )
                deleteItem(i);
            }).fail(function (msg) {
                swal(
                    'Failed',
                    'Your imaginary file is safe :)',
                    'error'
                )
            });
            
        }, function (dismiss) {
            // dismiss can be 'cancel', 'overlay',
            // 'close', and 'timer'
            if (dismiss === 'cancel') {
                console.log("eh ga kehapus");
                swal(
                    'Cancelled',
                    'Your imaginary file is safe :)',
                    'error'
                )
            }
        })
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/jurnal/form.blade.php ENDPATH**/ ?>