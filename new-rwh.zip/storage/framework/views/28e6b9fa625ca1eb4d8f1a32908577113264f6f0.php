<?php
    use App\Modul;
    use App\SubModul;
?>
<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">

        <!-- User -->
        <div class="user-box">
            <div class="user-img">
                <img src="<?php echo e(asset('assets/images/users/alvin.jpg')); ?>" alt="user-img" title="Mat Helme" class="rounded-circle img-thumbnail img-responsive">
                <div class="user-status offline"><i class="mdi mdi-adjust"></i></div>
            </div>
            <h5><a href="#">Superadmin</a> </h5>
            <ul class="list-inline">
                <li class="list-inline-item">
                    <a href="#" >
                        <i class="mdi mdi-settings"></i>
                    </a>
                </li>

                <li class="list-inline-item">
                    <a href="#" class="text-custom">
                        <i class="mdi mdi-power"></i>
                    </a>
                </li>
            </ul>
        </div>
        <!-- End User -->

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <ul>
                <?php $__currentLoopData = Modul::getAllModul(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="has_sub">
                        <a href="javascript:void(0);" class="waves-effect"><i class="<?php echo e($modul->modul_icon); ?>"></i><span><?php echo e($modul->modul_desc); ?></span> <span class="menu-arrow"></span></a>
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = SubModul::getSub($modul->modul_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="/<?php echo e($sub->submodul_page); ?>"><?php echo e($sub->submodul_desc); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div class="clearfix"></div>
        </div>
        <!-- Sidebar -->
        <div class="clearfix"></div>

    </div>

</div>
<!-- Left Sidebar End -->
<?php /* C:\xampp\htdocs\rwh\resources\views/layout/sidebar.blade.php */ ?>