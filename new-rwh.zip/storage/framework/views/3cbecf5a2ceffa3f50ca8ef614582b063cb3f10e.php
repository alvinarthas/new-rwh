<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Multi Item Selection examples -->
    <link href="<?php echo e(asset('assets/plugins/datatables/select.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul'); ?>
List Receive Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <div class="row">
                        <div class="col-12">
                            <div class="p-20">
                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Posting Period</label>
                                    <div class="col-5">
                                        <select class="form-control select2" parsley-trigger="change" name="bulan" id="bulan" required>
                                            <option value="#" selected disabled>Pilih Bulan</option>
                                            <?php for($i = 1; $i <= 12; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e(date("F", mktime(0, 0, 0, $i, 10))); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="col-5">
                                        <select class="form-control select2" parsley-trigger="change" name="tahun" id="tahun" required>
                                            <option value="#" selected disabled>Pilih Tahun</option>
                                            <?php for($i = 2018; $i <= date('Y'); $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group text-left m-b-0">
                        <a href="javascript:;" class="btn btn-custom btn-rounded waves-effect waves-light w-md m-b-5" onclick="choosePurchase()">Show Data</a>
                        <a href="javascript:;" class="btn btn-custom btn-rounded waves-effect waves-light w-md m-b-5" onclick="choosePurchase('all')">Show ALL Data</a>
                    </div>
                </div>

                <div id="receive-list" style="display:none">
                    <section id="showreceive">
                    </section>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Required datatable js -->
<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Responsive examples -->
<script src="<?php echo e(asset('assets/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script-js'); ?>
<script>

    function choosePurchase(id=null){
        bulan = $('#bulan').val();
        tahun = $('#tahun').val();
        
        $.ajax({
            url : "<?php echo e(route('receiveProdAjx')); ?>",
            type : "get",
            dataType: 'json',
            data:{
                bulan: bulan,
                tahun: tahun,
                jenis: id,
            },
        }).done(function (data) {
            document.getElementById("receive-list").style.display = 'block';
            $('#showreceive').html(data);
        }).fail(function (msg) {
            alert('Gagal menampilkan data, silahkan refresh halaman.');
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new-rwh\resources\views/purchase/receive/index.blade.php ENDPATH**/ ?>