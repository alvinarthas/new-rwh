@extends('layout.main')
@php
    use App\Modul;
    use App\SubModul;
@endphp

@section('css')
    
@endsection

@section('judul')
    
@endsection

@section('content')

@endsection

@section('js')
    
@endsection

@section('script-js')
    
@endsection