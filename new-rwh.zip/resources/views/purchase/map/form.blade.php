@extends('layout.main')
@php
    use App\SubModul;
    use App\MenuMapping;
@endphp
@section('css')
@endsection

@section('content')
    {{-- Current Menu Mapping --}}
    <form action="{{route('PurMapDelete')}}" method="post" enctype="multipart/form-data">
        @csrf
        <input type="hidden" name="user_id" value="{{$id}}">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">Current Mapping</h4>

                    <table id="responsive-datatable" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Perusahaan</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            @php($i = 1)
                            @foreach($currents as $current)
                            <tr>
                                <td>{{$i}}</td>
                                <td>{{$current->supplier->nama}}</td>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <input id="checkboxcurrent{{$current->supplier_id}}" name="current[]" type="checkbox" value="{{$current->supplier_id}}">
                                        <label for="checkboxcurrent{{$current->supplier_id}}"></label>
                                    </div>
                                </td>
                            </tr>
                            @php($i++)
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>

    {{-- Rest of Menu Mapping --}}
    <form action="{{route('PurMapStore')}}" method="post" enctype="multipart/form-data">
        @csrf
        <input type="hidden" name="user_id" value="{{$id}}">
        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title">List Supplier</h4>

                    <table id="responsive-datatable2" class="table table-bordered table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <th>No</th>
                            <th>Nama Supplier</th>
                            <th>Action</th>
                        </thead>

                        <tbody>
                            @php($i = 1)
                            @foreach($rests as $rest)
                            <tr>
                                <td>
                                    {{$i}}
                                </td>
                                <td>{{$rest->nama}}</td>
                                <td>
                                    <div class="checkbox checkbox-primary">
                                        <input id="checkboxrest{{$rest->id}}" name="rest[]" type="checkbox" value="{{$rest->id}}">
                                        <label for="checkboxrest{{$rest->id}}">
                                        </label>
                                    </div>
                                </td>
                            </tr>
                            @php($i++)
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end row -->

        <div class="form-group text-right m-b-0">
            <button class="btn btn-primary waves-effect waves-light" type="submit">
                Submit
            </button>
        </div>
    </form>
@endsection

@section('js')
@endsection

@section('script-js')
@endsection